#Build
javac -cp ./lib/json-simple-1.1.1.jar:./lib/ujmp-complete-0.2.5.jar:./lib/jmatio.jar -d build src/algorithms/*.java src/data_structure/*.java src/main/*.java src/utils/*.java

#Run example
java -XX:-UseGCOverheadLimit -cp ./lib/json-simple-1.1.1.jar:./lib/ujmp-complete-0.2.5.jar:./build main.main_tripartite
