package algorithms;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * PureSVD for topK recommender tasks is proposed in:
 * 	Paolo Cremonesi, Yehuda Koren, and Roberto Turrin. 2010. Performance of recommender 
 * 	algorithms on top-n recommendation tasks. In RecSys '10.
 * 
 * @author HeXiangnan
 *
 */
public class HFT extends TopKRecommender{

	HashMap<String, Integer> map_item_id; 
	HashMap<String, Integer> map_user_id; 
	
	double bias;
	SparseVector itemBias;
	SparseVector userBias;
	SparseMatrix itemFeatures;
	SparseMatrix userFeatures;
	SparseMatrix estimated;
	
	public HFT(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix, HashMap<String, Integer> map_user_id, 
			HashMap<String, Integer> map_item_id) {
		super(trainMatrix, validMatrix, testMatrix);
		this.map_item_id = map_item_id;
		this.map_user_id = map_user_id;
		itemBias = new SparseVector(itemCount);
		userBias = new SparseVector(userCount);
	}
	
	public void initModel(String user_modelFile, String item_modelFile, int featureCount) throws IOException {
		itemFeatures = new SparseMatrix(itemCount, featureCount);
		userFeatures = new SparseMatrix(userCount, featureCount);
		System.out.println("loading model...");
		readModelFromFiles(user_modelFile, item_modelFile);
		// Calculate the estimate matrix.
		System.out.println("Predicting ratings...");
		estimated = new SparseMatrix(userCount, itemCount);
		for (int u = 0; u < userCount; u ++) {
			for (int i = 0; i < itemCount; i ++) {
				double predict = bias + itemBias.getValue(i) + userBias.getValue(u) + 
						itemFeatures.getRowRef(i).innerProduct(userFeatures.getRowRef(u));
				estimated.setValue(u, i, predict);
			}
		}
	}
	
	public void buildModel(int startUser, int endUser) {
		// Generate itemRank list for each user.
		for (int u = startUser; u < endUser; u ++) {
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int item : estimated.getRowRef(u).indexList()) {
				map_item_score.put(item, estimated.getValue(u, item));
			}
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			this.topKItemsPerUser.set(u, topItems);
		}
	}

	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		ArrayList<ArrayList<Integer>> topKItems = new ArrayList<ArrayList<Integer>>();
		for (int u = 0; u < userCount; u++) {
			ArrayList<Integer> items = this.topKItemsPerUser.get(u);
			topKItems.add(new ArrayList<Integer>(
					items.subList(0, Math.min(maxTopK, items.size()))));
		}
		return new EvaluationMetrics(topKItems, testMatrix);
	}
	
	private void readModelFromFiles(String userFile, String itemFile) throws IOException {
		// Fill in user model.
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(userFile)));
		String line;
		while ((line = reader.readLine()) != null) {
			String[] arr = line.split(" ");
			int userId = map_user_id.get(arr[0]);
			bias = Double.parseDouble(arr[1]);
			userBias.setValue(userId, Double.parseDouble(arr[2]));
			for (int k = 3; k < arr.length; k ++) {
				userFeatures.setValue(userId, k-3, Double.parseDouble(arr[k]));
			}
		}
		reader.close();
		// Fill in item model.
		reader = new BufferedReader(new InputStreamReader(new FileInputStream(itemFile)));
		while ((line = reader.readLine()) != null) {
			String[] arr = line.split(" ");
			int itemId = map_item_id.get(arr[0]);
			bias = Double.parseDouble(arr[1]);
			itemBias.setValue(itemId, Double.parseDouble(arr[2]));
			for (int k = 3; k < arr.length; k ++) {
				itemFeatures.setValue(itemId, k-3, Double.parseDouble(arr[k]));
			}
		}
		reader.close();
		return;
	}
}
