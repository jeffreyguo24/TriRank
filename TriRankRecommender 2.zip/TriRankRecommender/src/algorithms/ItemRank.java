package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * Implemented ItemRank algorithm proposed in: Marco Gori and Augusto Pucci. 2007. 
 *   ItemRank: a random-walk based scoring algorithm for recommender engines. 
 *   In Proc. of IJCAI'07.
 * @author xiangnanhe
 *
 */
public class ItemRank extends TopKRecommender {

	/** Row-based L1 norm item-item transition matrix. */
	public SparseMatrix transition;
	
	/** Model parameters.*/
	private int maxIter;
	private boolean showProgress;
	private double alpha;
	
	public ItemRank(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
		
		this.transition = transitionMatrix(trainMatrix);
	}

	public void initModel(int maxIter, boolean showProgress, double alpha) {
		this.maxIter = maxIter;
		this.showProgress = showProgress;
		this.alpha = alpha;
		
		System.out.printf("ItemRank (alpha=%.2f) \n", alpha);
	}
	
	/**
	 * Initialize item-item transition matrix (row-based L1 norm).
	 * @param userItem
	 * @return
	 */
	public SparseMatrix transitionMatrix(SparseMatrix userItem) {
		int itemCount = userItem.length()[1];
		SparseMatrix transition = new SparseMatrix(itemCount, itemCount);
		
		for (int i = 0; i < itemCount; i ++) {
			HashSet<Integer> users1 = new HashSet<Integer>(
					userItem.getColRef(i).indexArrayList());
			for (int j = 0; j < i; j ++) {
				HashSet<Integer> users2 = new HashSet<Integer>(
						userItem.getColRef(j).indexArrayList());
				// Get users that has rated both item i and j.
				users2.retainAll(users1);
				transition.setValue(i, j, users2.size());
				transition.setValue(j, i, users2.size());
			}
		}
		transition = transition.rowStochastic();
		return transition;
	}
	
	/**
	 * PageRank algorithm with personalized vector.
	 *   PR = (1-alpha)*M*PR + alpha*d, where M is the transition matrix, d is the personalized vector.
	 */
	public void buildModel(int startUser, int endUser) {
		if (alpha >1 || alpha <0) {
			throw new RuntimeException("Error input of ItemRank.");
		}
		
		SparseMatrix transition_T = transition.transpose();
		
		double validHit = 0, testHit = 0;
		for (int u = startUser; u < endUser; u ++) {
			// Personalized vector of the user.
			SparseVector pVector = trainMatrix.getRowRef(u).L1_norm();
			// Item Ranking scores of the user.
			SparseVector uScore = SparseVector.makeUniform(itemCount);
			//SparseVector uScore = new SparseVector(pVector);
			
			int round = 0;
			while (round <= maxIter) {
				uScore = transition_T.times(uScore).scale(1 - alpha).plus(
						pVector.scale(alpha));
				round ++;
			}
			
			// Set rankScores of the user. Only set the maxTopK item scores.
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int item : uScore.indexList()) {
				map_item_score.put(item, uScore.getValue(item));
			}
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			for (int item : topItems) {
				rankScores.getRowRef(u).setValue(userCount + item, map_item_score.get(item));
			}
			
			// Update validHit.
			int[] validItemList = validMatrix.getRowRef(u).indexList();
			int[] testItemList = testMatrix.getRowRef(u).indexList();
			validHit += EvaluationMetrics.getHitRatio(topItems, validItemList);
			testHit += EvaluationMetrics.getHitRatio(topItems, testItemList);
			
			// showProgress
			if (showProgress && u % 100 == 0) {
				if (u == 0) {
					System.out.printf("User\t valid\t test\t\n");
				}
				int processed = u - startUser + 1;
				System.out.printf("%d\t %.4f\t %.4f\t \n", u, 
					validHit / processed, testHit / processed );
			}
		}
	}
}
