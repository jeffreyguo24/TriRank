package algorithms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * PureSVD for topK recommender tasks is proposed in:
 * 	Paolo Cremonesi, Yehuda Koren, and Roberto Turrin. 2010. Performance of recommender 
 * 	algorithms on top-n recommendation tasks. In RecSys '10.
 * 
 * @author HeXiangnan
 *
 */
public class PureSVD extends TopKRecommender{

	SparseMatrix itemFeatures;
	SparseMatrix userFeatures;
	SparseMatrix estimated;
	
	public PureSVD(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
	}
	
	public void initModel(String file_Ut, String file_Vt) throws IOException {
		userFeatures = SVDLIBCUtil.ReadSparseMatrixFromSTFile(file_Ut);
		itemFeatures = SVDLIBCUtil.ReadSparseMatrixFromSTFile(file_Vt).transpose();
		estimated = trainMatrix.times(itemFeatures).times(itemFeatures.transpose());
	}
	
	public void buildModel(int startUser, int endUser) {
		// Generate itemRank list for each user.
		for (int u = startUser; u < endUser; u ++) {
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int item : estimated.getRowRef(u).indexList()) {
				map_item_score.put(item, estimated.getValue(u, item));
			}
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			this.topKItemsPerUser.set(u, topItems);
		}
	}

	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		ArrayList<ArrayList<Integer>> topKItems = new ArrayList<ArrayList<Integer>>();
		for (int u = 0; u < userCount; u++) {
			ArrayList<Integer> items = this.topKItemsPerUser.get(u);
			topKItems.add(new ArrayList<Integer>(
					items.subList(0, Math.min(maxTopK, items.size()))));
		}
		return new EvaluationMetrics(topKItems, testMatrix);
	}
}
