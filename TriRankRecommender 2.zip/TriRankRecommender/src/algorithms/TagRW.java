package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * Implemented the random walk algorithm proposed in: 
 *  Zhang, Zhu, et al. "A random walk model for item recommendation in social tagging systems." 
 *  ACM Transactions on Management Information Systems (TMIS) 4.2 (2013): 8.
 *  
 *  Using the aspects as tags. 
 * @author xiangnanhe
 *
 */
public class TagRW extends TopKRecommender {

	/** Model parameters.*/
	private int maxIter;
	private boolean showProgress;
	private double eta,lambda;
	public double miu;
	
	/** Item-Tag and User-Tag matrix*/
	public SparseMatrix itemTag, userTag;
	/** Item-item and User-User similarity matrix*/
	public float[][] Sitem, Suser; 
	//public SparseMatrix Sitem, Suser;
	/** Rank score from item graph and user graph. */
	//public SparseMatrix UIitem, UIuser;
	public float[][] UIitem, UIuser;
	
	public TagRW(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix, SparseMatrix itemAspect, SparseMatrix userAspect) {
		super(trainMatrix, validMatrix, testMatrix);
		
		this.itemTag = itemAspect;
		this.userTag = userAspect;
		this.Sitem = new float[itemCount][itemCount];
		this.Suser = new float[userCount][userCount];
		//this.Sitem = new SparseMatrix(itemCount, itemCount);
		//this.Suser = new SparseMatrix(userCount, userCount);
		
		this.UIitem = matrixSet(trainMatrix.rowStochastic());
		this.UIuser = matrixSet(trainMatrix.rowStochastic());
		//this.UIitem = new SparseMatrix(trainMatrix.rowStochastic());
		//this.UIuser = new SparseMatrix(trainMatrix.rowStochastic());
	}
	
	/**
	 * 
	 * @param maxIter
	 * @param showProgress
	 * @param alpha Weight of item-tag in item similarity.
	 * @param beta Weight of user-tag in user similarity. 
	 * @param eta Weight of item transition of RW in item graph. 
	 * @param lambda Weight of user transition of RW in user graph. 
	 * @param miu Weight of final linear combination. 
	 */
	public void initModel(int maxIter, boolean showProgress, double alpha,
			double beta, double eta, double lambda, double miu) {
		this.maxIter = maxIter;
		this.showProgress = showProgress;
		this.eta = eta;
		this.lambda = lambda;
		this.miu = miu;
		
		System.out.printf("\t TagRW (alpha=%.2f,beta=%.2f,eta=%.2f,lambda=%.2f) \n",
				alpha, beta, eta, lambda, miu);
		
		/*
		// build similarity matrix using cosine-based
		float[] normItemTag = new float[itemCount]; 
		float[] normTrainMatrix = new float[itemCount]; 
		for (int i = 0; i < itemCount; i ++) { // save the normalization for calculating cosine similarity.
			normItemTag[i] = (float) Math.sqrt(itemTag.getRowRef(i).squareSum());
			normTrainMatrix[i] = (float) Math.sqrt(trainMatrix.getColRef(i).squareSum());
		}
		for (int i = 0; i < itemCount; i ++) {
			for (int j = 0; j < itemCount; j ++) {
				double tmp1 = itemTag.getRowRef(i).innerProduct(itemTag.getRowRef(j));
				if (tmp1 != 0)	tmp1 /= (normItemTag[i]*normItemTag[j]);
				double tmp2 = trainMatrix.getColRef(i).innerProduct(trainMatrix.getColRef(j));
				if (tmp2 != 0)	tmp2 /= (normTrainMatrix[i]*normTrainMatrix[j]);
				Sitem[i][j] = (float) (alpha * tmp1 + (1-alpha) * tmp2);
			}
		}
		
		float[] normUserTag = new float[userCount]; 
		normTrainMatrix = new float[userCount]; 
		for (int i = 0; i < userCount; i ++) { // save the normalization for calculating cosine similarity.
			normUserTag[i] = (float) Math.sqrt(userTag.getRowRef(i).squareSum());
			normTrainMatrix[i] = (float) Math.sqrt(trainMatrix.getRowRef(i).squareSum());
		}
		for (int i = 0; i < userCount; i ++) {
			for (int j = 0; j < userCount; j ++) {
				double tmp1 = userTag.getRowRef(i).innerProduct(userTag.getRowRef(j));
				if (tmp1 != 0)	tmp1 /= (normUserTag[i]*normUserTag[j]);
				double tmp2 = trainMatrix.getRowRef(i).innerProduct(trainMatrix.getRowRef(j));
				if (tmp2 != 0)	tmp2 /= (normTrainMatrix[i]*normTrainMatrix[j]);		
				Suser[i][j] = (float) (beta * tmp1 + (1-beta) * tmp2);
			}
		}
		colStochastic(Sitem);
		colStochastic(Suser);
		trainMatrix = trainMatrix.rowStochastic();
	*/
		
		// build similarity matrix using probability-based
		SparseMatrix itemTagT = itemTag.transpose().rowStochastic();
		itemTag = itemTag.rowStochastic();
		SparseMatrix trainMatrixT = trainMatrix.transpose().rowStochastic();
		trainMatrix = trainMatrix.rowStochastic();
		for (int i = 0; i < itemCount; i ++) {
			for (int j = 0; j < itemCount; j ++) {
				double tmp1 = alpha * itemTag.getRowRef(i).innerProduct(itemTagT.getColRef(j));
				double tmp2 = (1-alpha) * trainMatrixT.getRowRef(i).innerProduct(trainMatrix.getColRef(j));
				Sitem[i][j] = (float)(tmp1 + tmp2);
			}
		}				
		SparseMatrix userTagT = userTag.transpose().rowStochastic();
		userTag = userTag.rowStochastic();
		for (int i = 0; i < userCount; i ++) {
			for (int j = 0; j < userCount; j ++) {
				double tmp1 = beta * userTag.getRowRef(i).innerProduct(userTagT.getColRef(j));
				double tmp2 = (1-beta) * trainMatrix.getRowRef(i).innerProduct(trainMatrixT.getColRef(j));
				Suser[i][j] =  (float)(tmp1 + tmp2);
			}
		}
		colStochastic(Sitem);
		colStochastic(Suser);
		itemTag = userTag = userTagT = itemTagT = trainMatrixT = null;
		System.gc();
		
		
/*
		SparseMatrix M1 = itemTag.rowStochastic().times(itemTag.transpose().rowStochastic());
		SparseMatrix M2 = trainMatrix.transpose().rowStochastic().times(trainMatrix.rowStochastic());
		this.Sitem = M1.selfScale(alpha).plus(M2.selfScale(1 - alpha)).colStochastic();
		
		M1 = userTag.rowStochastic().times(userTag.transpose().rowStochastic());
		M2 = trainMatrix.rowStochastic().times(trainMatrix.transpose().rowStochastic());
		this.Suser = M1.selfScale(beta).plus(M2.selfScale(1 - beta)).colStochastic();
*/		
	}

	public void buildModel() {
		for (int iter = 1; iter <= maxIter; iter ++) {
			// Random walk updates
			for (int i = 0; i < userCount; i ++) {
				if (testMatrix.getRowRef(i).itemCount() == 0)	continue;
				SparseVector v = times(Sitem, getRowVector(UIitem, i, eta)).
					plus(trainMatrix.getRowRef(i).scale(1 - eta));
				setRowVector(UIitem, i, v);
			}
			for (int j = 0; j < itemCount; j ++) {
				SparseVector v = times(Suser, getColVector(UIuser, j, lambda)).
					plus(trainMatrix.getColRef(j).scale(1 - lambda));
				setColVector(UIuser, j, v);
			}
			
			// showProgress
			if (showProgress) {
				if (iter == 1) {
					System.out.printf("Iter(miu=)\t");
					for (miu = 0; miu <= 1; miu += 0.1)
						System.out.printf("%.2f\t", miu);
					System.out.println("");
				}
				System.out.print(iter + "\t\t");
				for (miu = 0; miu <= 1; miu += 0.1) {
					System.out.printf("%.4f\t", evalHRwithMiu(miu));
				}
				System.out.println("");
			}
		}
		
		// post-process
		post();
	}
	
	/**
	 * Random walk on user graph for [startItem, endItem]
	 * @param startItem
	 * @param endItem
	 */
	public void buildModelItem(int startItem, int endItem) {
		for (int j = startItem; j < endItem; j ++) {
			if (showProgress && (j - startItem) % 100 == 0)	System.out.printf(".");
			for (int iter = 1; iter <= maxIter; iter ++) {
				SparseVector v = times(Suser, getColVector(UIuser,j, lambda)).
					plus(trainMatrix.getColRef(j).scale(1 - lambda));
				setColVector(UIuser, j, v);
			}
		}
	}
	
	/**
	 * Random walk on item graph for [startUser, endUser]
	 * @param startUser
	 * @param endUser
	 */
	public void buildModelUser(int startUser, int endUser) {
		for (int i = startUser; i < endUser; i ++) {
			if (showProgress && (i - startUser) % 100 == 0)	System.out.printf(".");
			if (testMatrix.getRowRef(i).itemCount() == 0)	continue;
			for (int iter = 1; iter <= maxIter; iter ++) {
				SparseVector v = times(Sitem, getRowVector(UIitem, i, eta)).
						plus(trainMatrix.getRowRef(i).scale(1 - eta));
					setRowVector(UIitem, i, v);
			}
		}
	}
	
	
	/**
	 * Post-process the ranking process:
	 * 	1. Find the best miu
	 * 	2. Set rankScores. 
	 */
	public void post() {
		//System.out.println("");
		// Find best miu. 
		double bestHR = 0, bestMiu = 0;
		for (miu = 0; miu <= 1; miu += 0.1) {
			double hr = evalHRwithMiu(miu);
			if (bestHR < hr) {
				bestHR = hr;
				bestMiu = miu;
			}
		}
		miu = bestMiu;
		// Set rankScores. 
		for(int u = 0; u < userCount; u ++) {
			SparseVector score = getRowVector(UIitem, u, bestMiu).plus(
				getRowVector(UIuser, u, 1 - bestMiu));
			ArrayList<Integer> topItems = score.topIndicesByValue(maxTopK, trainMatrix.getRowRef(u).indexArrayList());
			for (int item : topItems) {
				rankScores.setValue(u, userCount + item, score.getValue(item));
			}
		}
	}
	
	/**
	 * Evaluate the HitRatio given miu. 
	 * @param miu
	 * @return
	 */
	public double evalHRwithMiu(double miu) {
		double hr = 0;
		int numUsers = 0;
		for(int u = 0; u < userCount; u ++) {
			int[] gtList = testMatrix.getRowRef(u).indexList();
			if (gtList == null)	continue;
			SparseVector score = getRowVector(UIitem, u, miu).plus(
					getRowVector(UIuser, u, 1 - miu));					
			ArrayList<Integer> topItems = score.topIndicesByValue(maxTopK, 
					trainMatrix.getRowRef(u).indexArrayList());
			hr += EvaluationMetrics.getHitRatio(topItems, gtList);
			numUsers ++;
		}
		return hr / numUsers;
	}

	@Override
	public void buildModel(int startUser, int endUser) {
		
	}
	
	
	/**
	 * Multiply a similarity matrix with a SparseVector. 
	 * @param S
	 * @param vector
	 * @return
	 */
	private SparseVector times(float[][] S, SparseVector vector) {
		int len = vector.length();
		SparseVector res = new SparseVector(len);
		if (vector.itemCount() == 0)	return res;
		
		for (int i = 0; i < len; i ++) {
			double val = 0;
			for (int j : vector.indexList()) {
				val += S[i][j] * vector.getValue(j);
			}
			res.setValue(i, val);
		}
		return res;
	}
	
	
	/**
	 * Convert a SparseMatrix to float[][] representation.
	 * @param M
	 * @return
	 */
	private float[][] matrixSet(SparseMatrix M) {
		int row = M.length()[0];
		int col = M.length()[1];
		float[][] res = new float[row][col];
		for (int i = 0; i < row; i ++) {
			for (int j : M.getRowRef(i).indexArrayList()) {
				res[i][j] = (float)M.getValue(i,j);
			}
		}
		return res;
	}
	
	/**
	 * L1 Normalize a matrix by its column. 
	 * @param S
	 */
	private void colStochastic(float[][] S) {
		int row = S.length;
		int col = S[0].length;
		
		for (int j = 0; j < col; j ++) {
			float sum = 0;
			for (int i = 0; i < row; i ++) {
				sum += S[i][j];
			}
			if (sum == 0)	continue;
			for (int i = 0; i < row; i ++) {
				S[i][j] /= sum;
			}
		}
	}
	
	/**
	 * Get the i-th row of a float[][] matrix. 
	 * @param M
	 * @param i
	 * @return
	 */
	private SparseVector getRowVector(float[][] M, int i, double scale) {
		SparseVector vector = new SparseVector(M[i].length);
		for (int j = 0; j < M[i].length; j ++) {
			if (M[i][j] == 0)	continue;
			vector.setValue(j, M[i][j]*scale);
		}
		return vector;
	}
	
	/**
	 * Get the j-th column of a float[][] matrix.
	 * @param M
	 * @param j
	 * @return
	 */
	private SparseVector getColVector(float[][] M, int j, double scale) {
		SparseVector vector = new SparseVector(M.length);
		for (int i = 0; i < M.length; i ++) {
			if (M[i][j] == 0)	continue;
			vector.setValue(i, M[i][j]*scale);
		}
		return vector;
	}
	
	private void setRowVector(float[][]M, int i, SparseVector newVector) {
		for(int j = 0; j < M[i].length; j ++) {
			M[i][j] = (float) newVector.getValue(j);
		}
	}
	
	private void setColVector(float[][]M, int j, SparseVector newVector) {
		for (int i = 0; i < M.length; i ++) {
			M[i][j] = (float) newVector.getValue(i);
		}
	}
}
