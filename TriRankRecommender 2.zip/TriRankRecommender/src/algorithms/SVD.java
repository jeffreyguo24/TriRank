package algorithms;

import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * This is class implementing Singular Value Decomposition (SVD) for recommendation.
 * Technical detail of the algorithm can be found in
 * Koren Yehuda and Bell Robert. 2011. Advances in Collaborative Filtering.
 * Recommender Systems Handbook, Springer, pages 145-186.
 *  
 * @author HeXiangnan
 * @since 2014. 11. 01
 * @version 1.0
 */
public class SVD extends TopKRecommender{
	
	/** The number of features. */
	public int featureCount;
	/** Learning rate parameter. */
	public double learningRate;
	/** Regularization factor parameter. */
	public double regularizer;
	/** Maximum number of iteration. */
	public int maxIter;
	
	/** Indicator whether to show progress of iteration. */
	public boolean showProgress;
	/** Offset to rating estimation. Usually this is the average of ratings. */
	public double offset;
	/** The bias terms for users and items. */
	public SparseVector userBias;
	public SparseVector itemBias;
	
	/** User profile in low-rank matrix form. */
	public SparseMatrix userFeatures;
	/** Item profile in low-rank matrix form. */
	public SparseMatrix itemFeatures;	
	
	public SVD(SparseMatrix trainMatrix, SparseMatrix validMatrix, 
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
	}
	
	private void initialize() {
		userFeatures = new SparseMatrix(userCount, featureCount);
		itemFeatures = new SparseMatrix(itemCount, featureCount);
		
		// Initialize user/item features:
		for (int u = 0; u < userCount; u++) {
			for (int f = 0; f < featureCount; f++) {
				double rdm = Math.random() / featureCount;
				userFeatures.setValue(u, f, rdm);
			}
		}
		for (int i = 0; i < itemCount; i++) {
			for (int f = 0; f < featureCount; f++) {
				double rdm = Math.random() / featureCount;
				itemFeatures.setValue(i, f, rdm);
			}
		}
		this.offset = trainMatrix.average(); // need to set the offset.
		this.userBias = new SparseVector(userCount);
		this.itemBias = new SparseVector(itemCount);
	}
	
	/**
	 * Model builder.
	 * 
	 * @param fc The number of features used for describing user and item profiles.
	 * @param lr Learning rate for gradient-based or iterative optimization.
	 * @param r Controlling factor for the degree of regularization. 
	 * @param iter The maximum number of iterations.
	 * @param verbose Indicating whether to show iteration steps and train error.
	 */
	public void buildModel(int fc, double lr, double r, int iter, boolean verbose) {
		featureCount = fc;
		learningRate = lr;
		regularizer = r;
		maxIter = iter;
		showProgress = verbose;
		this.initialize();

		int round = 0;
		double prevErr = 99999, prevValidErr = 99999;
		double currErr = 9999,  currValidErr = 9999;
		
		// Iterations:
		while (prevErr > currErr && prevValidErr > currValidErr && round < maxIter) {
			double sum_grad_i = 0, sum_itemFeatures = 0; // For tracking gradient influence.
			for (int u = 0; u < userCount; u++) {
				int[] itemList = trainMatrix.getRowRef(u).indexList();
				if (itemList == null) continue;
				
				for(int i : itemList) {
					// Compute prediction and error:
					double prediction = offset + userBias.getValue(u) + itemBias.getValue(i)
							+ userFeatures.getRowRef(u).innerProduct(itemFeatures.getRowRef(i));
					double e_ui = trainMatrix.getValue(u, i) - prediction;
					
					// Compute gradients and update for bias:
					double gradient = e_ui -  userBias.getValue(u) * regularizer;
					userBias.setValue(u, userBias.getValue(u) + gradient * learningRate);
					gradient = e_ui - itemBias.getValue(i) * regularizer;
					itemBias.setValue(i, itemBias.getValue(i) + gradient * learningRate);
					
					// Compute gradients for item latent features.
					SparseVector gradient_i = userFeatures.getRowRef(u).scale(e_ui).minus(
							itemFeatures.getRowRef(i).scale(regularizer));
					sum_itemFeatures += itemFeatures.getRowRef(i).squareSum();
					itemFeatures.setRowVector(i, 
							itemFeatures.getRowRef(i).plus(gradient_i.scale(learningRate)));
					sum_grad_i += gradient_i.squareSum();
					
					// Compute gradient for user latent features
					SparseVector gradient_u = itemFeatures.getRowRef(i).scale(e_ui).minus(
							userFeatures.getRowRef(u).scale(regularizer));
					userFeatures.setRowVector(u,
							userFeatures.getRowRef(u).plus(gradient_u.scale(learningRate)));
				}
			}
			
			round ++;
			
			// Update errors in training set:
			prevErr = currErr;
			currErr = getMSE(trainMatrix);
			
			// Update errors in validation set:
			prevValidErr = currValidErr;
			currValidErr = getMSE(validMatrix);
			
			//System.out.println("");
			// Show progress: 
			if (showProgress) {
				if (round == 1)
					System.out.println("Iter\t train\t valid\t test");
				System.out.printf("%d\t %.4f\t %.4f\t %.4f\n", round, currErr, currValidErr,
						getMSE(testMatrix));
				
				double train_error = currErr * trainMatrix.itemCount();
				double reg_b=0, reg_u=0, reg_i=0;
				for (int u = 0; u < userCount; u++) {
					int[] itemList = trainMatrix.getRowRef(u).indexList();
					if (itemList == null) continue;
					for(int i : itemList) {
						reg_b += Math.pow(userBias.getValue(u),2) + Math.pow(itemBias.getValue(i),2);
						reg_u += userFeatures.getRowRef(u).squareSum();
						reg_i += itemFeatures.getRowRef(i).squareSum();
					}
				}
				reg_b *= regularizer;
				reg_u *= regularizer;
				reg_i *= regularizer;
				double reg = reg_b + reg_u + reg_i;
				
				System.out.printf("      cost function = %.4f \t", train_error + reg);
				System.out.printf("train_err=%.1f  reg=%.1f (reg_b=%.1f  reg_u=%.1f  reg_i=%.1f)\n",
						train_error, reg, reg_b, reg_u, reg_i);
				System.out.printf("   sum_itemFeatures=%.2f, sum_grad_i=%.2f, ratio=%.4f%% \n", 
						sum_itemFeatures, sum_grad_i, (sum_grad_i/sum_itemFeatures)*100);
			}
		}
	}
	
	/**
	 * Get prediction error MSE of current model parameters with testMatrix.
	 */
	public double getMSE(SparseMatrix testMatrix) {
		SparseMatrix predicted = new SparseMatrix(userCount, itemCount);
		for (int u = 0; u < userCount; u++) {
			int[] itemList = testMatrix.getRowRef(u).indexList();
			if (itemList == null)	continue;
			for (int i : itemList) {
				predicted.setValue(u, i, getPredictionScore(u, i));
			}
		}
		return EvaluationMetrics.getMSE(predicted, testMatrix);
	}
	
	/**
	 * Get the prediction score of user u on item i.
	 * @param userid
	 * @param itemid
	 * @return
	 */
	public double getPredictionScore(int u, int i) {
		double prediction = offset + userBias.getValue(u) + itemBias.getValue(i)
				+ userFeatures.getRowRef(u).innerProduct(itemFeatures.getRowRef(i));
		return prediction;
	}

	
	@Override
	public void buildModel(int startUser, int endUser) {
		// TODO Auto-generated method stub
		
	}
}
