package algorithms;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * FISM algorithm. KDD'13.
 * Using the output of LibRec's implementation.
 * 
 * @author HeXiangnan
 *
 */
public class FISM extends TopKRecommender{
	
	ArrayList<ArrayList<Integer>> topKItems;
	public FISM(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
	}
	
	// Read top items output of LibRec's implementation.
	public void initModel(String topItemsFile) throws IOException {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(new FileInputStream(topItemsFile)));
		topKItems = new ArrayList<ArrayList<Integer>>();
		
		String line;
		while ((line = reader.readLine()) != null) {
			ArrayList<Integer> items = new ArrayList<Integer>();
			String[] arrs = line.split("\t");
			for (int i = 0; i < arrs.length; i ++) {
				items.add(Integer.parseInt(arrs[i]));
			}
			topKItems.add(items);
		}
		reader.close();
	}
	
	public void buildModel(int startUser, int endUser) {

	}

	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		return new EvaluationMetrics(topKItems, testMatrix);
	}
}
