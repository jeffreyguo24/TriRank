package algorithms;

import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

public class Adsorption extends TopKRecommender {

	/**A m*m matrix, denoting personalized label distribution for users. */
	public SparseMatrix labelDist;
	
	public Adsorption(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
	}
	
	/**
	 * Init label distribution.
	 * @param weight_p Weight of rated items in initializing label distribution.
	 * @return
	 */
	private SparseMatrix initLabelDist(double weight_p) {
		// Init popularity vector.
		SparseVector popScore = new SparseVector(userCount+itemCount);
		for (int i = 0; i < itemCount; i++) {
			popScore.setValue(userCount + i, trainMatrix.getColRef(i).itemCount());
		}
		popScore = popScore.L1_norm();
		// Init labelDist.
		SparseMatrix labelDist = new SparseMatrix(userCount, userCount+itemCount);
		for (int u = 0; u < userCount; u++) {
			int[] itemList = trainMatrix.getRowRef(u).indexList();
			if (itemList == null)	continue;
			SparseVector labelVector = new SparseVector(userCount + itemCount);
			for (int i : itemList) {
				labelVector.setValue(userCount + i, trainMatrix.getValue(u, i));
			}
			labelVector = labelVector.L1_norm();
			labelVector = labelVector.scale(weight_p).plus(popScore.scale(1 - weight_p));
			labelDist.setRowVector(u, labelVector);
		}
		return labelDist;
	}
	
	public void buildModel(int maxIter, boolean showProgress, double weight_p) {
		labelDist = initLabelDist(weight_p);
		System.out.printf("Adsorption, weight_p=%.4f\n", weight_p);
		int round = 0;
		while (round <= maxIter) {
			for (int k = 0; k < userCount; k ++) { // Build recommender model for each user.
				if (showProgress && k % 500 == 0)	System.out.print(".");
				SparseVector labelVector = labelDist.getRowRef(k);
				// Update for user vertices.
				for (int u = 0; u < userCount; u ++) {
					double val = 0;
					int[] neighbors = trainMatrix.getRowRef(u).indexList();
					if (neighbors == null)	continue;
					// neighbors are items.
					for (int i : neighbors) {
						val += trainMatrix.getValue(u, i) * labelVector.getValue(userCount + i);
					}
					labelVector.setValue(u, val);
				}
				// Update for item vertices.
				for (int i = 0; i < itemCount; i ++) {
					double val = 0;
					int[] neighbors = trainMatrix.getColRef(i).indexList();
					if (neighbors == null)	continue;
					// neighbors are users.
					for (int u : neighbors) {
						val += trainMatrix.getValue(u, i) * labelVector.getValue(u);
					}
					labelVector.setValue(userCount + i, val);
				}
				double norm = labelVector.sum();
				//labelVector.selfScale(1.0 / norm);
			}
			
			this.rankScores = labelDist;
			round ++;
			
			if (showProgress) {
				System.out.println("");
				if (round == 1) {
					System.out.printf("Iter\t train\t valid\t test\t\n");
				}
				EvaluationMetrics test = this.evaluate(testMatrix);
				System.out.printf("%d\t %.4f\t %.4f\t %.4f\t\n", round, 
						this.evaluate(trainMatrix).getHitRatio(false), 
						this.evaluate(validMatrix).getHitRatio(false), 
						test.getHitRatio(false));
			}
		}
	}

	@Override
	public void buildModel(int startUser, int endUser) {
		// TODO Auto-generated method stub
		
	}
}
