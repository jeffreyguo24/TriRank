package algorithms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import utils.TopKPriorityQueue;
import java.util.Map;
/**
 * This is an abstract class for topK recommender systems.
 * Define some variables to use, and member functions to implement by a topK recommender.
 * 
 * @author HeXiangnan
 * @since 2014.12.03
 */
public abstract class TopKRecommender {
	/** The number of users. */
	public int userCount;
	/** The number of items. */
	public int itemCount;
	
	/** Rating matrix of training set. Users by Items matrix.*/
	public SparseMatrix trainMatrix;
	/** Rating Matrix of validation set. */
	public SparseMatrix validMatrix;
	/** Rating Matrix of test set. */
	public SparseMatrix testMatrix;
	
	/** Maximum topK items to keep for each user. */
	protected final int maxTopK = 50;
	/** TopK recommender items for users.*/
	protected ArrayList<ArrayList<Integer>> topKItemsPerUser;
	
	/** m*(m+n) matrix, each row denotes the ranking scores for a user.
	 *  To be set by each method.*/
	public SparseMatrix rankScores;
	
	public TopKRecommender(SparseMatrix trainMatrix, SparseMatrix validMatrix, 
			SparseMatrix testMatrix) {
		this.userCount = trainMatrix.length()[0];
		this.itemCount = trainMatrix.length()[1];
		this.trainMatrix = trainMatrix;
		this.validMatrix = validMatrix;
		this.testMatrix = testMatrix;
		
		topKItemsPerUser = new ArrayList<ArrayList<Integer>>();
		for (int u = 0; u < userCount; u++) {
			topKItemsPerUser.add(new ArrayList<Integer>());
		}
		rankScores = new SparseMatrix(userCount, itemCount + userCount);
	}
	
	/**
	 * Build model for a range of users.
	 * Abstract method to be implemented by each algorithm.
	 * 
	 * @param startUser
	 * @param endUser
	 */
	public abstract void buildModel(int startUser, int endUser);
	
	/**
	 * Build model for all users.
	 */
	public void buildModel()
	{
		buildModel(0, userCount);
	}
	
	/**
	 * Get the prediction score of user u on item i.
	 * @param userid
	 * @param itemid
	 * @return
	 */
	public double getPredictionScore(int u, int i) {
		return this.rankScores.getValue(u, userCount + i);
	}
	
	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		for (int u = 0; u < userCount; u++) {
			// Map of item to its predicted score, for selecting topK items.
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int i = 0; i < itemCount; i++) {
				map_item_score.put(i, getPredictionScore(u, i));
			}
			// Selecting maxTopK items.
			ArrayList<Integer> topKeys = CommonUtils.TopKeysByValue(map_item_score, maxTopK, 
					this.trainItemsOfUser(u));
			this.topKItemsPerUser.set(u, topKeys);
		}
		return new EvaluationMetrics(this.topKItemsPerUser, testMatrix);
	}
	
	/**
	 * Get training items for a user, in order to ignore training items in producing topK results.
	 * @param u
	 * @return
	 */
	protected ArrayList<Integer> trainItemsOfUser(int u) {
		int[] itemList = trainMatrix.getRowRef(u).indexList();
		return CommonUtils.ArrayToArraylist(itemList);
	}
}
