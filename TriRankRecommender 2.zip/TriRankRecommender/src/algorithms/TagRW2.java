package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * Implemented the random walk algorithm proposed in: 
 *  Zhang, Zhu, et al. "A random walk model for item recommendation in social tagging systems." 
 *  ACM Transactions on Management Information Systems (TMIS) 4.2 (2013): 8.
 *  
 *  Using the aspects as tags. 
 * @author xiangnanhe
 *
 */
public class TagRW2 extends TopKRecommender {

	/** Model parameters.*/
	private int maxIter;
	private boolean showProgress;
	private double eta,lambda;
	public double miu;
	
	/** Item-Tag and User-Tag matrix*/
	public SparseMatrix itemTag, userTag;
	/** Item-item and User-User similarity matrix*/
	public SparseMatrix Sitem, Suser;
	/** Rank score from item graph and user graph. */
	public SparseMatrix UIitem, UIuser;
	
	public TagRW2(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix, SparseMatrix itemAspect, SparseMatrix userAspect) {
		super(trainMatrix, validMatrix, testMatrix);
		
		this.itemTag = itemAspect;
		this.userTag = userAspect;
		this.Sitem = new SparseMatrix(itemCount, itemCount);
		this.Suser = new SparseMatrix(userCount, userCount);
		
		trainMatrix = trainMatrix.rowStochastic();
		this.UIitem = new SparseMatrix(trainMatrix);
		this.UIuser = new SparseMatrix(trainMatrix);
	}
	
	/**
	 * 
	 * @param maxIter
	 * @param showProgress
	 * @param alpha Weight of item-tag in item similarity.
	 * @param beta Weight of user-tag in user similarity. 
	 * @param eta Weight of item transition of RW in item graph. 
	 * @param lambda Weight of user transition of RW in user graph. 
	 * @param miu Weight of final linear combination. 
	 */
	public void initModel(int maxIter, boolean showProgress, double alpha,
			double beta, double eta, double lambda, double miu) {
		this.maxIter = maxIter;
		this.showProgress = showProgress;
		this.eta = eta;
		this.lambda = lambda;
		this.miu = miu;
		
		System.out.printf("\t TagRW (alpha=%.2f,beta=%.2f,eta=%.2f,lambda=%.2f) \n",
				alpha, beta, eta, lambda, miu);
		

		SparseMatrix M1 = itemTag.rowStochastic().times(itemTag.transpose().rowStochastic());
		SparseMatrix M2 = trainMatrix.transpose().rowStochastic().times(trainMatrix.rowStochastic());
		this.Sitem = M1.selfScale(alpha).plus(M2.selfScale(1 - alpha)).colStochastic();
		
		M1 = userTag.rowStochastic().times(userTag.transpose().rowStochastic());
		M2 = trainMatrix.rowStochastic().times(trainMatrix.transpose().rowStochastic());
		this.Suser = M1.selfScale(beta).plus(M2.selfScale(1 - beta)).colStochastic();	
		
		trainMatrix = trainMatrix.rowStochastic();
	}
	
	public void buildModel() {
		for (int iter = 1; iter <= maxIter; iter ++) {
			// Random walk updates
			for (int i = 0; i < userCount; i ++) {
				if (testMatrix.getRowRef(i).itemCount() == 0)	continue;
				SparseVector v = Sitem.times(UIitem.getRowRef(i)).scale(eta).
					plus(trainMatrix.getRowRef(i).scale(1 - eta));
				UIitem.setRowVector(i, v);
			}
			for (int j = 0; j < itemCount; j ++) {
				SparseVector v = Suser.times(UIuser.getColRef(j)).scale(lambda).
					plus(trainMatrix.getColRef(j).scale(1 - lambda));
				UIuser.setColVector(j, v);
			}
			
			// showProgress
			if (showProgress) {
				if (iter == 1) {
					System.out.printf("Iter(miu=)\t");
					for (miu = 0; miu <= 1; miu += 0.1)
						System.out.printf("%.2f\t", miu);
					System.out.println("");
				}
				System.out.print(iter + "\t\t");
				for (miu = 0; miu <= 1; miu += 0.1) {
					System.out.printf("%.4f\t", evalHRwithMiu(miu));
				}
				System.out.println("");
			}
		}
		
		// post-process
		post();
	}
	
	/**
	 * Random walk on user graph for [startItem, endItem]
	 * @param startItem
	 * @param endItem
	 */
	public void buildModelItem(int startItem, int endItem) {
		for (int j = startItem; j < endItem; j ++) {
			if (showProgress && (j - startItem) % 100 == 0)	System.out.printf(".");
			for (int iter = 1; iter <= maxIter; iter ++) {
				SparseVector v = Suser.times(UIuser.getColRef(j)).scale(lambda).
					plus(trainMatrix.getColRef(j).scale(1 - lambda));
				UIuser.setColVector(j, v);
			}
		}
	}
	
	/**
	 * Random walk on item graph for [startUser, endUser]
	 * @param startUser
	 * @param endUser
	 */
	public void buildModelUser(int startUser, int endUser) {
		for (int i = startUser; i < endUser; i ++) {
			if (showProgress && (i - startUser) % 100 == 0)	System.out.printf(".");
			if (testMatrix.getRowRef(i).itemCount() == 0)	continue;
			for (int iter = 1; iter <= maxIter; iter ++) {
				SparseVector v = Sitem.times(UIitem.getRowRef(i)).scale(eta).
					plus(trainMatrix.getRowRef(i).scale(1 - eta));
				UIitem.setRowVector(i, v);
			}
		}
	}
	
	
	/**
	 * Post-process the ranking process:
	 * 	1. Find the best miu
	 * 	2. Set rankScores. 
	 */
	public void post() {
		System.out.println("");
		// Find best miu. 
		double bestHR = 0, bestMiu = 0;
		for (miu = 0; miu <= 1; miu += 0.1) {
			double hr = evalHRwithMiu(miu);
			if (bestHR < hr) {
				bestHR = hr;
				bestMiu = miu;
			}
		}
		miu = bestMiu;
		// Set rankScores. 
		for(int u = 0; u < userCount; u ++) {
			SparseVector score = UIitem.getRowRef(u).scale(bestMiu).plus(
				UIuser.getRowRef(u).scale(1 - bestMiu));
			ArrayList<Integer> topItems = score.topIndicesByValue(maxTopK, trainMatrix.getRowRef(u).indexArrayList());
			for (int item : topItems) {
				rankScores.setValue(u, userCount + item, score.getValue(item));
			}
		}
	}
	
	/**
	 * Evaluate the HitRatio given miu. 
	 * @param miu
	 * @return
	 */
	public double evalHRwithMiu(double miu) {
		double hr = 0;
		int numUsers = 0;
		for(int u = 0; u < userCount; u ++) {
			int[] gtList = testMatrix.getRowRef(u).indexList();
			if (gtList == null)	continue;
			SparseVector score = UIitem.getRowRef(u).scale(miu).plus(
				UIuser.getRowRef(u).scale(1 - miu));						
			ArrayList<Integer> topItems = score.topIndicesByValue(maxTopK, trainMatrix.getRowRef(u).indexArrayList());
			hr += EvaluationMetrics.getHitRatio(topItems, gtList);
			numUsers ++;
		}
		return hr / numUsers;
	}

	@Override
	public void buildModel(int startUser, int endUser) {
		
	}
	
	
	/**
	 * Multiply a similarity matrix with a SparseVector. 
	 * @param S
	 * @param vector
	 * @return
	 */
	private SparseVector times(double[][] S, SparseVector vector) {
		int len = vector.length();
		SparseVector res = new SparseVector(len);
		if (vector.itemCount() == 0)	return res;
		
		for (int i = 0; i < len; i ++) {
			double val = 0;
			for (int j : vector.indexList()) {
				val += S[i][j] * vector.getValue(j);
			}
			res.setValue(i, val);
		}
		return res;
	}
}
