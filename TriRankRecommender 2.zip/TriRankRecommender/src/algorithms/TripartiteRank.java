package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import utils.Printer;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.DatasetUtil;

public class TripartiteRank extends TopKRecommender {

	/** Normalized matrix of userItem, itemAspect and aspectUser */
	public SparseMatrix userItem;
	public SparseMatrix itemAspect;
	public SparseMatrix aspectUser;
	
	/** Transpose of the normalized matrices.*/
	public SparseMatrix itemUser;
	public SparseMatrix aspectItem;
	public SparseMatrix userAspect;
	
	private SparseMatrix itemAspectOriginal;
	private SparseMatrix aspectUserOriginal;
	
	public HashMap<String, Integer> map_aspect_id;
	/** Number of aspects */
	public int aspectCount;
	
	/** Model parameters. */
	int maxIter, topK;
	boolean showProgress;
	double alpha, beta, gamma, alpha0, beta0, gamma0;
	
	double dampUnrated = 0;

	public TripartiteRank(SparseMatrix trainMatrix, SparseMatrix validMatrix, SparseMatrix testMatrix,
			SparseMatrix itemAspect, SparseMatrix aspectUser, HashMap<String, Integer> map_aspect_id) {
		super(trainMatrix, validMatrix, testMatrix);
		
		this.aspectUserOriginal = aspectUser;
		
		
		this.userItem = symmetricNorm(trainMatrix);
		this.itemAspect = symmetricNorm(itemAspect);
		this.userAspect = symmetricNorm(aspectUser.transpose());
		
		this.itemUser = this.userItem.transpose();
		this.aspectItem = this.itemAspect.transpose();
		this.aspectUser = this.userAspect.transpose();
		/* .//PageRank settings.
		this.itemUser = trainMatrix.rowStochastic().transpose();
		this.aspectItem = itemAspect.rowStochastic().transpose();
		this.userAspect = aspectUser.rowStochastic().transpose();
		
		this.userItem = trainMatrix.transpose().rowStochastic().transpose();
		this.itemAspect = itemAspect.transpose().rowStochastic().transpose();
		this.aspectUser = aspectUser.transpose().rowStochastic().transpose();*/
		
		this.aspectCount = aspectUser.length()[0];
		this.map_aspect_id = map_aspect_id;
	}
	
	public void initModel(int maxIter, boolean showProgress, int topK, double alpha, double beta, 
			double gamma, double alpha0, double beta0, double gamma0) {
		this.maxIter = maxIter; this.topK = topK;
		this.showProgress = showProgress;
		this.alpha = alpha; this.beta = beta; this.gamma = gamma;
		this.alpha0 = alpha0; this.beta0 = beta0; this.gamma0 = gamma0;
		this.dampUnrated = 1;
		
		System.out.printf("TriRank (alpha, beta, gamma, a0, b0, g0) = "
				+ "%.2f, %.2f, %.2f, %.2f, %.2f, %.2f \n", 
				this.alpha, this.beta, this.gamma, this.alpha0, this.beta0, this.gamma0);
	}
	
	/**
	 * Init uPscore for a user, use the current user.
	 * @param u The user to initialize for.
	 * @return
	 */
	private SparseVector initUPscore(int u){
		SparseVector uPscore = new SparseVector(userCount);
		uPscore.setValue(u, 1.0);
		// initialize other users using cosine similarity.
		/*for (int i = 0; i < userCount; i ++) {
			if (i == u)	continue;
			uPscore.setValue(i, SparseVector.cosineSimilarity(
					trainMatrix.getRowRef(u), trainMatrix.getRowRef(i)));
		}*/
		return uPscore.L1_norm();
	}
	
	/**
	 * Init iPscore for a user, use the items that the current user has rated and 
	 * the popularity of each item.
	 * @param u The user to initialize for.
	 * @return
	 */
	private SparseVector initIPscore(int u) {
		// If the user has no train items, using the item popularity as score.  
		if (trainMatrix.getRowRef(u).itemCount() == 0) {
			SparseVector iPscore = new SparseVector(itemCount);
			for (int i = 0; i < itemCount; i ++) {
				iPscore.setValue(i, trainMatrix.getColRef(i).itemCount());
			}
			return iPscore.L1_norm();
		}
		return trainMatrix.getRowRef(u).L1_norm();
	}
	
	/**
	 * Init aPscore for a user, use the aspects that the current user has reviewed.
	 * @param u The user to initialize for.
	 * @return
	 */
	private SparseVector initAPscore(int u) {
		SparseVector aPscore = aspectUserOriginal.getColRef(u).L1_norm();
		return aPscore;
	}
	
/** Inference the ranking score using stochastic gradient descent.
 * @param startUser
 * @param endUser
 */
	/*
public void buildModel(int startUser, int endUser) {
	double lr = 0.001;
	if (startUser == 0) {
		System.out.printf("TriRankSGD: learningRate = %.4f, dampUnrated = %.2f, maxIter = %d\n", 
			lr, dampUnrated, maxIter);
	}
	
	int[] pShuffle = new int[itemCount];
	int[] uShuffle = new int[userCount];
	int[] aShuffle = new int[aspectCount];
	for (int j = 0; j < pShuffle.length; j ++) 
		pShuffle[j] = j;
	for (int i = 0; i < uShuffle.length; i ++)
		uShuffle[i] = i;
	for (int k = 0; k < aShuffle.length; k ++)
		aShuffle[k] = k;
	
	double validHit = 0, testHit = 0;
	// Build model for each user.
	// The prediction different users can be multi-threaded.
	for (int u = startUser; u < endUser; u++) {
		Long start = System.currentTimeMillis();
		// Personalized score for users, items and aspects.
		SparseVector uPscore = initUPscore(u);
		SparseVector iPscore = initIPscore(u, weight_p);
		SparseVector aPscore = initAPscore(u, 1);
		// Rank scores for users, items and aspects.
		SparseVector userVector = new SparseVector(uPscore);
		SparseVector itemVector = new SparseVector(iPscore);
		SparseVector aspectVector = new SparseVector(aPscore);
		//SparseVector userVector = SparseVector.makeRandom(userCount).L1_norm();
		//SparseVector itemVector = SparseVector.makeRandom(itemCount).L1_norm();
		//SparseVector aspectVector = SparseVector.makeRandom(aspectCount).L1_norm();
		
		HashSet<Integer> ratedItems = new HashSet<Integer>(
				trainMatrix.getRowRef(u).indexArrayList());
		int round = 0;
		while (round < maxIter) {
			// Update for items
			CommonUtils.ShuffleArray(pShuffle);
			for (int j : pShuffle) {
				double grad = 0;
				if (ratedItems.contains(j)) { // training instance
					grad = alpha*(itemVector.getValue(j) - userItem.getColRef(j).innerProduct(userVector))
						+ beta* (itemVector.getValue(j) - itemAspect.getRowRef(j).innerProduct(aspectVector))
						+ beta0*(itemVector.getValue(j) - iPscore.getValue(j));
				} else { // negative instance
					grad = alpha*(itemVector.getValue(j) - userItem.getColRef(j).innerProduct(userVector))
						+ beta* (itemVector.getValue(j) - itemAspect.getRowRef(j).innerProduct(aspectVector))
						+ beta0*dampUnrated*(itemVector.getValue(j) - iPscore.getValue(j));
				}

				double newVal = itemVector.getValue(j) - grad * lr;
				itemVector.setValue(j, newVal);
			}
			
			// Update for users
			CommonUtils.ShuffleArray(uShuffle);
			for (int i : uShuffle) {
				double grad = alpha*(userVector.getValue(i) - userItem.getRowRef(i).innerProduct(itemVector))
							+ gamma*(userVector.getValue(i) - userAspect.getRowRef(i).innerProduct(aspectVector))
							+ alpha0*(userVector.getValue(i) - uPscore.getValue(i));
				double newVal = userVector.getValue(i) - grad*lr;
				userVector.setValue(i, newVal);
			}
			
			// Update for aspects
			CommonUtils.ShuffleArray(aShuffle);
			for (int k : aShuffle) {
				double grad = beta*(aspectVector.getValue(k) - itemAspect.getColRef(k).innerProduct(itemVector))
							+ gamma*(aspectVector.getValue(k) - userAspect.getColRef(k).innerProduct(userVector))
							+ gamma0*(aspectVector.getValue(k) - aPscore.getValue(k));
				double newVal = aspectVector.getValue(k) - grad*lr;
				aspectVector.setValue(k, newVal);
			}
			round ++;
		}
		
		//System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		
		// Generate item ranklist for the user.
		HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
		for (int item : itemVector.indexList()) {
			map_item_score.put(item, itemVector.getValue(item));
		}
		ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
				this.maxTopK, this.trainItemsOfUser(u));
		this.topKItemsPerUser.set(u, topItems);
		
		// Update validScore.
		int[] validItemList = validMatrix.getRowRef(u).indexList();
		int[] testItemList = testMatrix.getRowRef(u).indexList();
		double currentHit = EvaluationMetrics.getHitRatio(topItems, testItemList);
		validHit += EvaluationMetrics.getHitRatio(topItems, validItemList);
		testHit += EvaluationMetrics.getHitRatio(topItems, testItemList);
		
		if (showProgress) {
			if (u == 0) {
				System.out.printf("Users\t Valid\t Test\t CurTest\t Tests\t Preds\n");
				continue;
			}
			if (u % 1 == 0 || u == userCount - 1) {
				int processed = u - startUser + 1;
				System.out.printf("%d\t %.4f\t %.4f\t %.4f\t %d%s\t %d%s \n", u, validHit / processed, testHit / processed, currentHit, 
					testMatrix.getRowRef(u).itemCount(), testMatrix.getRowRef(u).KeysToString(),
					topItems.size(), topItems.toString());
			}
		}
	}
}	*/
	/**
	 * Build model for a range of users, from startUser to endUser. For multi-threading.
	 * @param maxIter
	 * @param alpha	Weight of user-item
	 * @param beta 	Weight of item-aspect
	 * @param gamma Weight of aspect-user
	 * @param alpha0 Weight of user personalized vector
	 * @param beta0  Weight of item personalized vector
	 * @param gamma0 Weight of aspect personalized vector 
	 * @param weight_p The relative weight of rated items in personalized vector.
	 */
	public void buildModel(int startUser, int endUser) {
		double validHit = 0, testHit = 0;
		// Build model for each user.
		// The prediction different users can be multi-threaded.
		for (int u = startUser; u < endUser; u++) {
			if (testMatrix.getRowRef(u).itemCount() == 0) {
				startUser ++;
				continue;
			}
			// Personalized score for users, items and aspects.
			SparseVector uPscore = initUPscore(u);
			SparseVector iPscore = initIPscore(u);
			SparseVector aPscore = initAPscore(u);
			// Initial rank scores for users, items and aspects.
			SparseVector userVector = new SparseVector(uPscore);
			SparseVector itemVector = new SparseVector(iPscore);
			SparseVector aspectVector = new SparseVector(aPscore);
			
			int round = 0;
			while (round < maxIter) {
				// Update for user rank scores.
				userVector = userItem.times(itemVector).scale(alpha / (alpha+gamma+alpha0));
				userVector = userVector.plus(
						userAspect.times(aspectVector).scale(gamma / (alpha+gamma+alpha0)));
				userVector = userVector.plus(uPscore.scale(alpha0 / (alpha+gamma+alpha0)));
				// Update for item rank scores.
				itemVector = itemAspect.times(aspectVector).scale(beta / (beta+alpha+beta0));
				itemVector = itemVector.plus(
						itemUser.times(userVector).scale(alpha / (beta+alpha+beta0)));
				itemVector = itemVector.plus(iPscore.scale(beta0 / (beta+alpha+beta0)));
				// Update for aspect .
				aspectVector = aspectUser.times(userVector).scale(gamma / (gamma+beta+gamma0));
				aspectVector = aspectVector.plus(
						aspectItem.times(itemVector).scale(beta / (gamma+beta+gamma0)));
				aspectVector = aspectVector.plus(aPscore.scale(gamma0 / (gamma+beta+gamma0)));
				
				round ++;
			}
			
			//System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
			
			// Generate item ranklist for the user.
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int item : itemVector.indexList()) {
				map_item_score.put(item, itemVector.getValue(item));
			}
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			this.topKItemsPerUser.set(u, topItems);
			
			// Update validScore.
			int[] validItemList = validMatrix.getRowRef(u).indexList();
			int[] testItemList = testMatrix.getRowRef(u).indexList();
			double currentHit = EvaluationMetrics.getHitRatio(topItems, testItemList);
			validHit += EvaluationMetrics.getHitRatio(topItems, validItemList);
			testHit += EvaluationMetrics.getHitRatio(topItems, testItemList);
			
			if (showProgress) {
				if (u == 0) {
					System.out.printf("Users\t Test\t CurTest\t Tests\t Trains\t\t Aspects\t Preds\n");
				}
				if (u % 1 == 0 || u == userCount - 1) {
					int processed = u - startUser + 1;
					System.out.printf("%d\t %.4f\t %.4f\t %d%s\t %d\t%s\t %d%s\t %d%s \n", u, testHit / processed, currentHit, 
						testMatrix.getRowRef(u).itemCount(), testMatrix.getRowRef(u).KeysToString(),
						trainMatrix.getRowRef(u).itemCount(), trainMatrix.getRowRef(u).KeysToString(),
						userAspect.getRowRef(u).itemCount(), userAspect.getRowRef(u).KeysToString(),
						topItems.size(), topItems.toString());
				}
			}
		}
	}
	
	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		ArrayList<ArrayList<Integer>> topKItems = new ArrayList<ArrayList<Integer>>();
		for (int u = 0; u < userCount; u++) {
			ArrayList<Integer> items = this.topKItemsPerUser.get(u);
			topKItems.add(new ArrayList<Integer>(
					items.subList(0, Math.min(topK, items.size()))));
		}
		return new EvaluationMetrics(topKItems, testMatrix);
	}
	
	/**
	 * Symmetrically normalize a matrix.
	 * @param W
	 * @return
	 */
	private SparseMatrix symmetricNorm(SparseMatrix W) {
		int rowNum = W.length()[0];
		int colNum = W.length()[1]; 
		SparseMatrix S_w = new SparseMatrix(rowNum, colNum);
		
		// Weighted degree (sqrt) of row-wise and col-wise, for normalization.
		SparseVector D_row = new SparseVector(rowNum);
		SparseVector D_col = new SparseVector(colNum);
		for (int i = 0; i < rowNum; i++) {
			D_row.setValue(i, Math.sqrt(W.getRowRef(i).sum()));
		}
		for (int j = 0; j < colNum; j++) {
			D_col.setValue(j, Math.sqrt(W.getColRef(j).sum()));
		}
		
		// Set normalized matrix.
		for (int i = 0; i < rowNum; i++) {
			int[] indexList = W.getRowRef(i).indexList();
			if (indexList == null)	continue;
			for (int j : indexList) {
				S_w.setValue(i, j, W.getValue(i, j) / (D_row.getValue(i)*D_col.getValue(j)));
			}
		}
		
		return S_w;
	}
}
