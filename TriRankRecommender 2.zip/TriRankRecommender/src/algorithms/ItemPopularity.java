package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;

public class ItemPopularity extends TopKRecommender {

	HashMap<Integer, Double> map_item_popularity;
	
	public ItemPopularity(SparseMatrix trainMatrix, SparseMatrix validMatrix, 
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
	}
	
	public void buildModel() {
		map_item_popularity = new HashMap<Integer, Double>();
		for (int i = 0; i < itemCount; i++) {
			// Measure popularity by number of reviews received.
			double popularity = trainMatrix.getColRef(i).itemCount();
			map_item_popularity.put(i, popularity);
		}
	}
	
	public EvaluationMetrics evaluate(SparseMatrix testMatrix) {
		// Set topK items for each user.
		for (int u = 0; u < userCount; u++) {
			this.topKItemsPerUser.set(u, 
					CommonUtils.TopKeysByValue(map_item_popularity, maxTopK, this.trainItemsOfUser(u)));
		}
		return new EvaluationMetrics(this.topKItemsPerUser, testMatrix);
	}

	@Override
	public void buildModel(int startUser, int endUser) {
		// TODO Auto-generated method stub
		
	}
}
