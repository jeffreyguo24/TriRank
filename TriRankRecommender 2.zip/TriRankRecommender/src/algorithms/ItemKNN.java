package algorithms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

/**
 * Implement ItemKNN method for topK recommendation, as described in:
 * Collaborative filtering for implicit feedback datasets. By Yifan Hu , Yehuda Koren , Chris Volinsky.
 * In IEEE ICDM'2008.
 * 
 * @author xiangnanhe
 *
 */
public class ItemKNN extends TopKRecommender {

	/** Similarity matrix of item-item . */
	public SparseMatrix similarityMatrix;
	
	/** The most similar K items for each item. */
	private ArrayList<ArrayList<Integer>> kSimilarItems;
	
	/** Model parameters.*/
	private int K;
	private boolean showProgress;
	
	public ItemKNN(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
		this.similarityMatrix = similarityMatrix(trainMatrix);
	}

	/**
	 * 
	 * @param showProgress
	 * @param K Number of item neighbors to consider. When the value is less or equal than 0, 
	 * 		  all items are considered as neighbors. 
	 */
	public void initModel(boolean showProgress, int K) {
		this.showProgress = showProgress;
		this.K = K;
		System.out.printf("ItemKNN (K=%d) \n", K);
		
		if (K <= 0)	return;
		// Init kSimilarItems.
		kSimilarItems = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < itemCount; i ++) {
			int[] indexList = similarityMatrix.getRowRef(i).indexList();
			if (indexList == null) {
				kSimilarItems.add(new ArrayList<Integer>());
				continue;
			}
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int j : indexList) {
				map_item_score.put(j, similarityMatrix.getValue(i, j));
			}
			kSimilarItems.add(CommonUtils.TopKeysByValue(map_item_score, K, null));
		}
	}
	
	/**
	 * Initialize item-item transition matrix (row-based L1 norm).
	 * @param userItem
	 * @return
	 */
	public SparseMatrix similarityMatrix(SparseMatrix userItem) {
		int itemCount = userItem.length()[1];
		SparseMatrix similarityMatrix = new SparseMatrix(itemCount, itemCount);
		
		for (int i = 0; i < itemCount; i ++) {
			for (int j = 0; j < i; j ++) {
				double similarity = SparseVector.cosineSimilarity(userItem.getColRef(i), 
						userItem.getColRef(j));
				similarityMatrix.setValue(i, j, similarity);
				similarityMatrix.setValue(j, i, similarity);
			}
		}
		
		return similarityMatrix;
	}
	
	public void buildModel(int startUser, int endUser) {
		double validHit = 0, testHit = 0;
		for (int u = startUser; u < endUser; u ++) {
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			for (int i = 0; i < itemCount; i ++) {
				if (K <= 0) {
					map_item_score.put(i, trainMatrix.getRow(u).innerProduct(similarityMatrix.getRowRef(i)));
					continue;
				}
				double score = 0;
				for (int j : kSimilarItems.get(i)) {
					score += trainMatrix.getValue(u, j) * similarityMatrix.getValue(i, j);
				}
				map_item_score.put(i, score);
			}
			
			// Set rankScores of the user. Only set the maxTopK item scores.
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			for (int item : topItems) {
				rankScores.getRowRef(u).setValue(userCount + item, map_item_score.get(item));
			}
			
			// Update validHit.
			int[] validItemList = validMatrix.getRowRef(u).indexList();
			int[] testItemList = testMatrix.getRowRef(u).indexList();
			validHit += EvaluationMetrics.getHitRatio(topItems, validItemList);
			testHit += EvaluationMetrics.getHitRatio(topItems, testItemList);
			
			// showProgress
			if (showProgress && u % 100 == 0) {
				if (u == 0) {
					System.out.printf("User\t valid\t test\t\n");
				}
				int processed = u - startUser + 1;
				System.out.printf("%d\t %.4f\t %.4f\t \n", u, 
					validHit / processed, testHit / processed );
			}
		}
	}
}
