package algorithms;

import java.util.ArrayList;
import java.util.HashMap;

import utils.CommonUtils;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import data_structure.SparseVector;

public class PageRank extends TopKRecommender {

	/**Transition matrix is of dimension (m+n)*(m+n), should be row-based L1 norm.*/
	SparseMatrix transition;
	/** Each row represents personalized vector of a user. */
	SparseMatrix pUserMatrix;
	
	/** Model parameters.*/
	private int maxIter;
	private boolean showProgress;
	private double alpha;
	
	/**
	 * PageRank on the user-item graph.
	 * @param trainMatrix
	 * @param validMatrix
	 * @param testMatrix
	 * @param minValue
	 * @param maxValue
	 */
	public PageRank(SparseMatrix trainMatrix, SparseMatrix validMatrix,
			SparseMatrix testMatrix) {
		super(trainMatrix, validMatrix, testMatrix);
		
		// Set transition matrix.
		transition = this.transitionMatrix(trainMatrix);
	}
	
	/**
	 * PageRank on the user-item-aspect graph.
	 * @param weight_aspect Weight of userAspect VS userItem in the transition matrix.
	 */
	public PageRank(SparseMatrix trainMatrix, SparseMatrix validMatrix, SparseMatrix testMatrix,
			SparseMatrix itemAspect, SparseMatrix userAspect, double weight_IA, double weight_UA) {
		super(trainMatrix, validMatrix, testMatrix);
		
		// Set transition matrix.
		if (weight_IA == 0 && weight_UA == 0) {
			transition = this.transitionMatrix(trainMatrix);
		} else {
			System.out.printf("PageRank with item-aspect (%.2f) and user-aspect (%.2f) ", weight_IA, weight_UA);
			transition = this.transitionMatrix(trainMatrix, itemAspect, userAspect, weight_IA, weight_UA);
		}
	}
	
	public void initModel(int maxIter, boolean showProgress, double alpha) {
		this.maxIter = maxIter;
		this.showProgress = showProgress;
		this.alpha = alpha;
		
		System.out.printf("PageRank (alpha=%.2f) \n", alpha);
	}
	
	/**
	 * The damping factor in PageRank.
	 * PR = (1-alpha)*M*PR + alpha*d, where M is the transition matrix, d is the personalized vector.
	 */
	public void buildModel(int startUser, int endUser) {
		if (alpha >1 || alpha <0) {
			throw new RuntimeException("Error input of PageRank.");
		}
		
		SparseMatrix transition_T = transition.transpose();
		
		double validHit = 0, testHit = 0;
		for (int u = startUser; u < endUser; u ++) {
			// Personalized vector of the user.
			SparseVector pVector = transition.getRow(u);
			// Ranking scores of the user.
			SparseVector uScore = transition.getRow(u);
			
			int round = 0;
			while (round <= maxIter) {
				uScore = transition_T.times(uScore).scale(1 - alpha).plus(
						pVector.scale(alpha));
				round ++;
			}
			
			// Set rankScores of the user. Only set the maxTopK item scores.
			HashMap<Integer, Double> map_item_score = new HashMap<Integer, Double>();
			if (uScore.indexList() != null) {
				for (int index : uScore.indexList()) {
					if (index >= userCount && index < userCount + itemCount) {
						int item = index - userCount;
						map_item_score.put(item, uScore.getValue(userCount + item));
					}
				}
			}
			ArrayList<Integer> topItems = CommonUtils.TopKeysByValue(map_item_score, 
					this.maxTopK, this.trainItemsOfUser(u));
			for (int item : topItems) {
				rankScores.getRowRef(u).setValue(userCount + item, map_item_score.get(item));
			}
			
			// Update validHit.
			int[] validItemList = validMatrix.getRowRef(u).indexList();
			int[] testItemList = testMatrix.getRowRef(u).indexList();
			validHit += EvaluationMetrics.getHitRatio(topItems, validItemList);
			testHit += EvaluationMetrics.getHitRatio(topItems, testItemList);
			
			// showProgress
			if (showProgress && u % 1 == 0) {
				if (u == 0) {
					System.out.printf("User\t valid\t test\t test_u\t predicted\n");
				}
				int processed = u - startUser + 1;
				System.out.printf("%d\t %.4f\t %.4f\t %.4f\t %d%s\n", u, 
					validHit / processed, testHit / processed, EvaluationMetrics.getHitRatio(topItems, testItemList), 
					topItems.size(), topItems.toString());
			}
		}
	}
		
	/**
	 * Construct (m+n)*(m+n) transitonMatrix from m*n user-item rateMatrix.
	 * 
	 * @param matrix
	 * @return the symmetrical transition matrix. 
	 */
	private SparseMatrix transitionMatrix(SparseMatrix rateMatrix) {
		int userCount = rateMatrix.length()[0];
		int itemCount = rateMatrix.length()[1];
		
		SparseMatrix transition = new SparseMatrix(userCount + itemCount, userCount + itemCount);
		for (int u = 0; u < userCount; u++) {
			int[] itemList = rateMatrix.getRowRef(u).indexList();
			if (itemList == null)	continue;
			for (int i : itemList) {
				int rowIndex = u;
				int colIndex = userCount + i;
				transition.setValue(rowIndex, colIndex, rateMatrix.getValue(u, i));
				transition.setValue(colIndex, rowIndex, rateMatrix.getValue(u, i));
			}
		}
		// Make the transition matrix as row-based L1 norm.
		transition = transition.rowStochastic(); 
		return transition;
	}
	
	/**
	 * Construct (m+n+a)*(m+n+a) transition matrix from userItem, itemAspect and userAspect matrix.
	 * @return
	 */
	private SparseMatrix transitionMatrix(SparseMatrix trainMatrix, SparseMatrix itemAspect, 
			SparseMatrix userAspect, double weight_IA, double weight_UA) {
		int userCount = trainMatrix.length()[0];
		int itemCount = trainMatrix.length()[1];
		int aspectCount = userAspect.length()[1];
		
		SparseMatrix userItem = trainMatrix.rowStochastic();
		itemAspect = itemAspect.rowStochastic().scale(weight_IA);
		userAspect = userAspect.rowStochastic().scale(weight_UA);
		
		SparseMatrix transition = new SparseMatrix(userCount + itemCount + aspectCount, 
				userCount + itemCount + aspectCount);
		// Initialize for user-item and user-aspect part.
		for (int u = 0; u < userCount; u++) {
			// user-item part.
			int[] itemList = userItem.getRowRef(u).indexList();
			if (itemList != null) {
				for (int i : itemList) {
					transition.setValue(u, userCount + i, userItem.getValue(u, i));
					transition.setValue(userCount + i, u, userItem.getValue(u, i));
				}
			}
			// user-aspect part.
			int[] aspectList = userAspect.getRowRef(u).indexList();
			if (aspectList != null) {
				for (int a : aspectList) {
					transition.setValue(u, userCount + itemCount + a, userAspect.getValue(u, a));
					transition.setValue(userCount + itemCount + a, u, userAspect.getValue(u, a));
				}
			}
		}
		// Initialize for item-aspect part;
		for (int i = 0; i < itemCount; i++) {
			int[] aspectList = itemAspect.getRowRef(i).indexList();
			if (aspectList == null)	continue;
			for (int a : aspectList) {
				transition.setValue(userCount + i, userCount + itemCount + a, itemAspect.getValue(i, a));
				transition.setValue(userCount + itemCount + a, userCount + i, itemAspect.getValue(i, a));
			}
		}
		
		// row-based L1 norm;
		transition = transition.rowStochastic();
		return transition;
	}
	
	/**
	 * Construct the personalized vector of a user.
	 * @param transition the (m+n)*(m+n) transition matrix.
	 * @param u
	 * @return a (m+n)*1 vector s.t. each element denotes the rated item of the user.
	 */
	private SparseVector pUserVector(SparseMatrix transition, int u) {
		SparseVector pVector = new SparseVector(transition.length()[0]);
		int[] itemList = transition.getRowRef(u).indexList();
		if (itemList == null)	return pVector;
		for (int i : itemList) {
			pVector.setValue(i, transition.getValue(u, i));
		}
		// L1 norm on the vector.
		return pVector.L1_norm();
	}
	
	/**
	 * Init the PR scores.
	 * Only init item nodes as we aim at ranking items.
	 * @param method 
	 */
	private SparseMatrix initPRscores(String method) {
		SparseMatrix initScores= new SparseMatrix(userCount, userCount+itemCount);
		// System.out.println("Init pagerank as " + method);
		
		if (method.equals("personalized")) { // Init PR scores as personalized vectors.
			for (int u = 0; u < userCount; u ++) {
				initScores.setRowVector(u, pUserVector(transition, u));
			}
		}
		if (method.equals("random")) { // Randomly init PR scores.
			for (int u = 0; u < userCount; u ++) {
				SparseVector vector = new SparseVector(userCount+itemCount);
				for (int i = 0; i < itemCount; i++) {
					vector.setValue(userCount+i, Math.random());
				}
				initScores.setRowVector(u, vector.L1_norm());
			}
		}
		if (method.equals("uniform")) { // Uniformly init PR scores.
			for (int u = 0; u < userCount; u ++) {
				SparseVector vector = new SparseVector(userCount+itemCount);
				for (int i = 0; i < itemCount; i++) {
					vector.setValue(userCount+i, 1.0);
				}
				initScores.setRowVector(u, vector.L1_norm());
			}
		}
		if (method.equals("popularity")) { // Init PR scores as the item popularity
			for (int u = 0; u < userCount; u ++) {
				SparseVector vector = new SparseVector(userCount+itemCount);
				for (int i = 0; i < itemCount; i++) {
					vector.setValue(userCount+i, trainMatrix.getColRef(i).itemCount());
				}
				initScores.setRowVector(u, vector.L1_norm());
			}
		}
		return initScores;
	}
}


