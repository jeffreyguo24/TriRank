package utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import data_structure.SparseMatrix;

public class EvaluationMetrics {
	
	private ArrayList<ArrayList<Integer>> topItemsPerUser;
	private SparseMatrix testMatrix;
	private int userCount;
	
	public EvaluationMetrics(ArrayList<ArrayList<Integer>> topItemsPerUser, 
			SparseMatrix testMatrix) {
		if (topItemsPerUser.size() != testMatrix.length()[0]) {
			throw new RuntimeException("User dimension does not match in testing.");
		}
		userCount = topItemsPerUser.size();
		this.topItemsPerUser = topItemsPerUser;
		this.testMatrix = testMatrix;
	}
	
	/**
	 * Get the hitRatio@k.
	 * 1. First get hitRatio of each user.
	 * 2. Average the hitRatio of all users.
	 * 
	 * @k	Number of top items to evaluate.
	 * @showEachUser Whether to show the hitRatio of each user.
	 * @return 
	 */
	public double getHitRatio(int k, boolean showEachUser) {
		double sumRatio = 0;
		int countUsers = 0; // Count number of users have test item.
		for (int u = 0; u < userCount; u++) {
			int[] gtList = testMatrix.getRowRef(u).indexList();
			if (gtList == null || gtList.length == 0)	continue;
			
			List<Integer> topItems = topItemsPerUser.get(u);
			topItems = topItems.subList(0, Math.min(k, topItems.size()));
			double hitRatio = this.getHitRatio(topItems, gtList);
			sumRatio += hitRatio;
			countUsers ++;
			
			if (showEachUser) {
				if (u == 0)		System.out.println("uid\t HitRatio\t gtList\t predictList");
				System.out.printf("%d\t %.4f\t %s\t %s\n", u, hitRatio, CommonUtils.ArrayToArraylist(gtList), topItems);
			}
		}
		return sumRatio / countUsers;
	}
	
	/**
	 * Get the hitRatio.
	 * 1. First get hitRatio of each user.
	 * 2. Average the hitRatio of all users.
	 * 
	 * @showEachUser Whether to show the hitRatio of each user.
	 * @return 
	 */
	public double getHitRatio(boolean showEachUser) {
		double sumRatio = 0;
		int countUsers = 0; // Count number of users have test item.
		for (int u = 0; u < userCount; u++) {
			int[] gtList = testMatrix.getRowRef(u).indexList();
			if (gtList == null || gtList.length == 0)	continue;
			
			List<Integer> topItems = topItemsPerUser.get(u);
			double hitRatio = this.getHitRatio(topItems, gtList);
			sumRatio += hitRatio;
			countUsers ++;
			
			if (showEachUser) {
				if (u == 0)		System.out.println("uid\t HitRatio");
				System.out.printf("%d\t %.4f\n", u, hitRatio);
			}
		}
		return sumRatio / countUsers;
	}
	
	/**
	 * Get the NDCG@k of the topK recommendation.
	 * 1. First get NDCG@k of each user.
	 * 2. Average the NDCG@k of all users.
	 * @param k
	 * @showEachUser Whether to show the NDCG@k of each user.
	 * @return
	 */
	public double getNDCG(int k, boolean showEachUser) {
		double sumNDCG = 0;
		int countUsers = 0; // Count number of users have test item.
		for (int u = 0; u < userCount; u++) {
			int[] gtList = testMatrix.getRowRef(u).indexList();
			if (gtList == null || gtList.length == 0)	continue;
			
			List<Integer> topItems = topItemsPerUser.get(u);
			topItems = topItems.subList(0, Math.min(k, topItems.size()));
			double ndcg = this.getNDCG(topItems, gtList);
			sumNDCG += ndcg;
			countUsers ++;
			
			if (showEachUser) {
				if (u == 0)		System.out.println("uid\t NDCG@k");
				System.out.printf("%d\t %.4f\n", u, ndcg);
			}
		}
		return sumNDCG / countUsers;
	}
	
	public static double getHitRatio(List<Integer> topItems, int[] gtItemList) {
		if (gtItemList == null || gtItemList.length == 0)
			return 0;
		
		HashSet<Integer> topItemSet = new HashSet<Integer>(topItems);
		int hitCount = 0;
		for (int i : gtItemList) {
			if (topItemSet.contains(i))	hitCount++;
		}
		return (double) hitCount / (double) gtItemList.length;
	}
	
	public static double getNDCG(List<Integer> topItems, int[] gtItemList) {
		if (gtItemList == null || gtItemList.length == 0)
			return 0;
	
		HashSet<Integer> correctItems = new HashSet<Integer> (
				CommonUtils.ArrayToArraylist(gtItemList));
		return computeNDCG(topItems, correctItems);
	}
	
	/**
	 * Compute the normalized discounted cumulative gain (NDCG) of a list of ranked items.
	 * See http://recsyswiki.com/wiki/Discounted_Cumulative_Gain
	 * 
	 * @param ranked_items  ranked_items a list of ranked item IDs, the highest-ranking item first
	 * @param correct_items correct_items a collection of positive/correct item IDs.
	 * @return the NDCG for the given data.
	 */
	private static double computeNDCG(List<Integer> ranked_items, HashSet<Integer> correct_items) {
		double dcg = 0;
		double idcg = computeIDCG(correct_items.size());

		for (int i = 0; i < ranked_items.size(); i++) {
			int item_id = ranked_items.get(i);
			if (!correct_items.contains(item_id))
				continue;

			// compute NDCG part
			int rank = i + 1;
			dcg += Math.log(2) / Math.log(rank + 1);
		}
		return dcg / idcg;
	}
	
	private static double computeIDCG(int n)
	{
	    double idcg = 0;
	    for (int i = 0; i < n; i++)
	      idcg += Math.log(2) / Math.log(i + 2);
	    return idcg;
	}

	
	/**
	 * Return the Mean Squared Error of a prediction matrix with the test Matrix.
	 * @param predicted
	 * @param test
	 * @return
	 */
	public static double getMSE(SparseMatrix predicted, SparseMatrix test) {
		double se = 0; // squared error;
		int userCount = test.length()[0];
		for (int u = 0; u < userCount; u++) {
			int[] itemList = test.getRowRef(u).indexList();
			if(itemList == null)	continue;
			for (int i : itemList) {
				se += Math.pow(test.getValue(u, i) - predicted.getValue(u, i), 2);
			}
		}
		double mse = se / test.itemCount();
		return mse;
	}
}
