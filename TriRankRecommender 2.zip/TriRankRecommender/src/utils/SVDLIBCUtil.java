package utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import com.jmatio.io.MatFileReader;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLSparse;

import data_structure.SparseMatrix;

/**
 * Utils for supporting SVDLIBC
 * http://tedlab.mit.edu/~dr/SVDLIBC/
 * 
 * @author xiangnanhe
 */

public class SVDLIBCUtil {

	/**
	 * Convert a sparseMatrix to ST format and output to file.
	 * Example of ST format (sparse text) used by SVDLIBC:
	 * http://tedlab.mit.edu/~dr/SVDLIBC/SVD_F_ST.html
	 * 
	 * @return
	 * @throws FileNotFoundException 
	 */
	public static void SparseMatrixToST(SparseMatrix matrix, String outFile) throws FileNotFoundException {
		int numRows = matrix.length()[0];
		int numCols = matrix.length()[1];
		int totalNonZeroValues = matrix.itemCount();
		
		PrintWriter writer = new PrintWriter (new FileOutputStream(outFile));

		writer.printf("%d %d %d\n", numRows, numCols, totalNonZeroValues);
		for (int col = 0; col < numCols; col ++) {
			int rowCount = matrix.getColRef(col).itemCount();
			writer.printf("%d\n", rowCount);
			int[] indexList = matrix.getColRef(col).indexList();
			if (indexList == null)	continue;
			for (int row : indexList) {
				writer.printf("%d %.1f\n", row, matrix.getValue(row, col), col);
			}
		}
		
		System.out.println("Generated ST (sparse text) file: " + outFile);
		writer.close();
	}
	
	
	/**
	 * Read ST file and convert to SparseMatrix
	 * @param inFile
	 * @return
	 * @throws IOException
	 */
	public static SparseMatrix ReadSparseMatrixFromSTFile(String inFile) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inFile)));
		String line = reader.readLine();
		int numRows = Integer.parseInt(line.split(" ")[0]);
		int numCols = Integer.parseInt(line.split(" ")[1]);
		SparseMatrix matrix = new SparseMatrix(numRows, numCols);
		
		int col = 0;
		while ((line = reader.readLine()) != null && col < numCols) {
			// Process the elements of the column col.
			int rowCount = Integer.parseInt(line.trim());
			if (rowCount > 0) {
				for (int i = 0; i < rowCount; i ++) {
					line = reader.readLine();
					int row = Integer.parseInt(line.split(" ")[0]);
					double val = Double.parseDouble(line.split(" ")[1]);
					matrix.setValue(row, col, val);
				}
			}
			col ++;
		}
		reader.close();
		return matrix;
	}
	
	public static void main(String[] args) throws IOException {
		/*
		SparseMatrix M = new SparseMatrix(4, 4);
		M.setValue(0, 0, 2.3);
		M.setValue(0, 2, 4.2);
		M.setValue(1, 1, 1.3);
		M.setValue(1, 2, 2.2);
		M.setValue(2, 0, 3.8);
		M.setValue(2, 2, 0.5);
		
		SVDLIBCUtil.SparseMatrixToST(M, "SVDLIBC/data/test.st");
		
		SparseMatrix MR = SVDLIBCUtil.ReadSparseMatrixFromSTFile("SVDLIBC/data/test.st");
		System.out.printf("Size: %d, %d;  Number of nonZeros: %d\n", MR.length()[0], MR.length()[1], MR.itemCount());
		System.out.println(MR.toString()); */
	}

}
