package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;
import algorithms.PureSVD;

public class main_pureSVD extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		String dataset_name = "yelp_reviews_220K_i10_u10";
		//String dataset_name = "Electronics_i10_u10";
		int threadNum = 3;
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		
		System.out.println("===================================================================");
		
		// Run baseline algorithms
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;

		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		
		int[] weights = {5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150};
		for (int featureCount : weights) {
			PureSVD pureSVD = new PureSVD(trainMatrix, validMatrix, testMatrix);
			pureSVD.initModel(String.format("SVDLIBC/output/%s/%d/-Ut", dataset_name, featureCount), 
					String.format("SVDLIBC/output/%s/%d/-Vt", dataset_name, featureCount));
			metrics = RunModelMultiThread(pureSVD, threadNum);
			
			System.out.printf("PureSVD(%d)\t %.4f\t %.4f \n", featureCount, 
					metrics.getHitRatio(false), metrics.getNDCG(topK, false));
			
			// Run for SVD.
			SVD svd = new SVD(trainMatrix, validMatrix, testMatrix);
			svd.buildModel(featureCount, 0.005, 0.01, 200, false);
			metrics = svd.evaluate(testMatrix);
			System.out.printf("SVD(%d)\t %.4f\t %.4f \n", featureCount, metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		}
		/*
		double[] rs = {0.01, 0.1, 0.5, 1, 5, 10, 50, 100, 200, 500, 1000};
		for(double regularizer : rs) {
			SVD svd = new SVD(trainMatrix, validMatrix, testMatrix, minValue, maxValue);
			svd.buildModel(20, 0.005, regularizer, 200, false);
			
			
		}*/
	}
}
