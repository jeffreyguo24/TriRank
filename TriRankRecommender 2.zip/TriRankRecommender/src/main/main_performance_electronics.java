package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemKNN;
import algorithms.ItemPopularity;
import algorithms.ItemRank;
import algorithms.PageRank;
import algorithms.PureSVD;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

public class main_performance_electronics extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		String dataset_name = "Electronics_i10_u10";
		//String dataset_name = "Electronics_u2_9";
		String lexiconFile = "datasets/lexicon/Electronics.lexicon";		
		
		boolean showProgress = false;
		int maxIter = 10;
		int threadNum = 3;
		double alpha, beta, gamma, alpha0, beta0, gamma0;
		
		if (argv.length > 0) {
			threadNum = Integer.parseInt(argv[0]);
		}
		
		System.out.println("Performance comparasion for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, "tfidf", 1);
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		System.out.println("===================================================================");
		
		int topK = 50, startK = 10;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		
		// ItemPop
		Long start = System.currentTimeMillis();
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		EvaluationMetrics metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK);
		
		// ItemKNN
		start = System.currentTimeMillis();
		ItemKNN itemKNN = new ItemKNN(trainMatrix, validMatrix, testMatrix);
		itemKNN.initModel(showProgress, 0);
		metrics = RunModelMultiThread(itemKNN, threadNum);
		System.out.printf("ItemKNN\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK);
		
		// PureSVD
		start = System.currentTimeMillis();
		PureSVD pureSVD = new PureSVD(trainMatrix, validMatrix, testMatrix);
		pureSVD.initModel(String.format("SVDLIBC/output/%s/%d/-Ut", dataset_name, 30), String.format("SVDLIBC/output/%s/%d/-Vt", dataset_name, 20));
		metrics = RunModelMultiThread(pureSVD, threadNum);
		System.out.printf("PureSVD\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK);
		
		/*
		// TriRank
		start = System.currentTimeMillis();
		TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect.transpose(), map_aspect_id);
		triRank.initModel(maxIter, showProgress, topK, alpha=9, beta=6, gamma=0.05, alpha0=0.1, beta0=2, gamma0=1, 1, 1);
		metrics = RunModelMultiThread(triRank, threadNum);
		System.out.printf("TriRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK); */
		
		// PageRank
		start = System.currentTimeMillis();
		PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect, 0, 0);
		pagerank.initModel(maxIter, showProgress, alpha=0.3);
		metrics = RunModelMultiThread(pagerank, threadNum);
		System.out.printf("PageRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK);
		
		// ItemRank
		start = System.currentTimeMillis();
		ItemRank itemrank = new ItemRank(trainMatrix, validMatrix, testMatrix);
		itemrank.initModel(maxIter, showProgress, alpha=0.3);
		metrics = RunModelMultiThread(itemrank, threadNum);
		System.out.printf("ItemRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, startK, topK);
		
		/* Doesnot perform well on topK recommendation.
		// BiasedMF (standard latent factor model)
		SVD svd = new SVD(trainMatrix, validMatrix, testMatrix);
		svd.buildModel(20, 0.005, 0.01, 200, false);
		metrics = svd.evaluate(testMatrix);
		System.out.printf("BiasedMF\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		*/
	}
}
