package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.HFT;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

import algorithms.PureSVD;

public class main_HFT extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		String dataset_name = "yelp"; int featureCount = 30;
		
		//String dataset_name = "amazon"; int featureCount = 30;
		int threadNum = 3;
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
		}
		if (dataset_name == "yelp") {
			String dataset_name2 = "yelp_reviews_220K_i10_u10";
			System.out.println("Run for dataset: " + dataset_name2);
			String trainFile = "datasets/train/" + dataset_name2 + ".votes";
			String validFile = "datasets/validation/" + dataset_name2 + ".votes";
			String testFile  = "datasets/test/" + dataset_name2 + ".votes";
			readRatingsFromSplits(trainFile, validFile, testFile);
		} else if (dataset_name == "amazon") {
			String dataset_name2 = "Electronics_i10_u10";
			System.out.println("Run for dataset: " + dataset_name2);
			String trainFile = "datasets/train/" + dataset_name2 + ".votes";
			String validFile = "datasets/validation/" + dataset_name2 + ".votes";
			String testFile  = "datasets/test/" + dataset_name2 + ".votes";
			readRatingsFromSplits(trainFile, validFile, testFile);
		}
		
		System.out.println("===================================================================");
		
		// Run baseline algorithms
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;

		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		

		HFT hft = new HFT(trainMatrix, validMatrix, testMatrix, map_user_id, map_item_id);
		hft.initModel(String.format("HFT/%s.%d.user.model", dataset_name, featureCount), 
					  String.format("HFT/%s.%d.item.model", dataset_name, featureCount), 
					  featureCount);
		metrics = RunModelMultiThread(hft, threadNum);
		
		System.out.printf("HFT(%d)\t %.4f\t %.4f \n", featureCount, 
				metrics.getHitRatio(false), metrics.getNDCG(topK, false));
			
	}
}
