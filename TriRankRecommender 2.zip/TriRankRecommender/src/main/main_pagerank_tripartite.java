package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import utils.Printer;

/**
 * Run PageRank on User-Item-Aspect tripartite graph. 
 * Tuning parameter of weight_IA and weight_UA.
 * 
 * @author HeXiangnan
 *
 */
public class main_pagerank_tripartite extends main{
	public static void main(String argv[]) throws IOException, InterruptedException {
		String dataset_name = "yelp_reviews_220K_i10_u10";
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
		double alpha = 0.9; 
		
		/*String dataset_name = "Electronics_i10_u10";
		String lexiconFile = "datasets/lexicon/Electronics.lexicon";
		double alpha = 0.3; */
		
		int threadNum = 3;
		int maxIter = 10;
		Boolean showProgress = false;
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			if (dataset_name.contains("yelp"))	{
				lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
				alpha = 0.9;
			}
			if (dataset_name.contains("Electronics")){
				lexiconFile = "datasets/lexicon/Electronics.lexicon";
				alpha = 0.3;
			}
			threadNum = Integer.parseInt(argv[1]);
		}
		System.out.println("Run PageRank on User-Item-Aspect tripartite graph: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		// Read votes file with split:
		// DatasetUtil.SplitsVotesFileByTimeAllButK("datasets/", dataset_name, 3);
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, "tfidf", 1);
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		System.out.println("===================================================================");
		
		// Run baseline algorithms
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;
		
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		
		Long start;
		double[] weights = {0.1, 1, 2, 3};
		double best_weight_IA=-1, best_weight_UA=-1, bestAlpha = -1;
		double bestHR = 0;
		
		/*
		for(alpha = 0.1; alpha < 1; alpha += 0.1) {
			// Grid search to tuning weight_IA and weight_UA.
			for (double weight_UA : weights) {
				for (double weight_IA : weights) {
					start = System.currentTimeMillis();
					PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix,
							itemAspect, userAspect, weight_IA, weight_UA);
					pagerank.initModel(maxIter, showProgress, alpha);
					metrics = RunModelMultiThread(pagerank, threadNum);
					
					double HR = metrics.getHitRatio(false);
					System.out.printf("PageRank\t %.4f\t %.4f ", HR, metrics.getNDCG(topK, false));
					System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
					
					if (bestHR < HR) {
						best_weight_IA = weight_IA;
						best_weight_UA = weight_UA;
						bestAlpha = alpha;
						bestHR = HR;
					}
				}
			}
			System.out.printf("So far, bestHR is %.4f, best_weight_IA = %.1f, best_weight_UA = %.1f, "
					+ "bestAlpha = %.1f\n", bestHR, best_weight_IA, best_weight_UA, bestAlpha);
		}
		System.out.printf("BestHR is %.4f, best_weight_IA = %.1f, best_weight_UA = %.1f, "
				+ "bestAlpha = %.1f\n", bestHR, best_weight_IA, best_weight_UA, bestAlpha); */
		
		for (double weight_IA = 0; weight_IA <= 0.1; weight_IA += 0.01) {
			start = System.currentTimeMillis();
			PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix,
					itemAspect, userAspect, weight_IA, 0);
			pagerank.initModel(maxIter, showProgress, alpha);
			metrics = RunModelMultiThread(pagerank, threadNum);
			
			double HR = metrics.getHitRatio(false);
			System.out.printf("PageRank\t %.4f\t %.4f ", HR, metrics.getNDCG(topK, false));
			System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		}
		
		for (double weight_UA = 0; weight_UA <= 0.1; weight_UA += 0.01) {
			start = System.currentTimeMillis();
			PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix,
					itemAspect, userAspect, 0, weight_UA);
			pagerank.initModel(maxIter, showProgress, alpha);
			metrics = RunModelMultiThread(pagerank, threadNum);
			
			double HR = metrics.getHitRatio(false);
			System.out.printf("PageRank\t %.4f\t %.4f ", HR, metrics.getNDCG(topK, false));
			System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		}

	}
}
