package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.FISM;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import algorithms.TagRW2;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

import algorithms.PureSVD;
import algorithms.TagRW;
public class main_tagRW extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		double alpha,beta,eta,lambda,miu; 
		
		/*String dataset_name = "yelp_reviews_220K_i10_u10"; 
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
		alpha=0.95; beta=0.18; eta=0.05; lambda=0.2; miu=0.9; //15.25 */
		
		String dataset_name = "Electronics_i10_u10";
		String lexiconFile = "datasets/lexicon/Electronics.lexicon";
		alpha=0.9; beta=0.1; eta=0.1; lambda=0.9; miu=0.8; //17.47
		
		int maxIter = 5;
		alpha = 0.95; // item-tag similarity VS item-user similarity
		beta = 0.1; // user-tag similarity VS user-item similarity
		eta = 0.1; // item graph RW
		lambda = 0.4; // user graph RW 
		
		int threadNum = 3;
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			if (dataset_name.contains("yelp"))	lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
			if (dataset_name.contains("Electronics"))	lexiconFile = "datasets/lexicon/Electronics.lexicon";
			alpha = Double.parseDouble(argv[1]);
			beta = Double.parseDouble(argv[2]);
			eta = Double.parseDouble(argv[3]);
			lambda = Double.parseDouble(argv[4]);
			threadNum = Integer.parseInt(argv[5]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, 
				lexiconFile, "tfidf", 1);
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		System.out.println("===================================================================");
		
		// Run baseline algorithms
		int topK = 50;
		System.out.printf("Evaluating TagRW for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;

		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		
		/*double bestHIT = 0;
		for (eta = 0.05; eta <= 0.4; eta += 0.05) {
			for (lambda = 0.05; lambda <= 0.4; lambda += 0.05) { */
				Long start = System.currentTimeMillis();
				TagRW rw = new TagRW(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect);
				rw.initModel(maxIter, false, alpha, beta, eta, lambda, miu);
				metrics = RunTagRWMultiThread(rw, threadNum);
				//rw.buildModel();
				//metrics = rw.evaluate(testMatrix);
				double hitRatio = metrics.getHitRatio(true);
				double ndcg = metrics.getNDCG(topK, true);
				System.out.printf("TagRW(bestMiu=%.2f)\t %.4f\t %.4f [%s]\n\n", 
						rw.miu, hitRatio , ndcg, Printer.printTime(System.currentTimeMillis() - start));
				/*bestHIT = Math.max(bestHIT, hitRatio);
			}
			System.out.printf("Best hr is %.4f, \n", bestHIT);
		}*/
		printEvaluation(metrics, 10, 50);
	}
}
