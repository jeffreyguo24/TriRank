package main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

public class main_tripartite extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		double alpha, beta, gamma, alpha0, beta0, gamma0;
		String dataset_name = "yelp_reviews_220K_i10_u10";
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";		
		alpha=6; beta=3; gamma=0.05; alpha0=5.00; beta0=100; gamma0=80; // 18.58  
		
		double dampUnrated = 1;
		
		/*String dataset_name = "Electronics_i10_u10";
		String lexiconFile = "datasets/lexicon/Electronics.lexicon";
		alpha=11.00; beta=6; gamma=0.2; alpha0=0.12; beta0=2.00; gamma0=1.00;  //18.44 */
		
		boolean showProgress = false;
		int threadNum = 3;
		String aspectFilteringMode = "tfidf";
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			if (dataset_name.contains("yelp"))	lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
			if (dataset_name.contains("Electronics"))	lexiconFile = "datasets/lexicon/Electronics.lexicon";
			alpha = Double.parseDouble(argv[1]);
			beta  = Double.parseDouble(argv[2]);
			gamma = Double.parseDouble(argv[3]);
			alpha0= Double.parseDouble(argv[4]);
			beta0 = Double.parseDouble(argv[5]);
			gamma0= Double.parseDouble(argv[6]);
			threadNum = Integer.parseInt(argv[7]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		// Read votes file with split:
		// DatasetUtil.SplitsVotesFileByTimeAllButK("datasets/", dataset_name, 3);
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		/*// Output rating file as the input of FISM.
		OutputRatingFile(trainMatrix, "datasets/train/" + dataset_name+".rating");
		OutputRatingFile(testMatrix, "datasets/test/" + dataset_name+".rating"); */
		
		
		System.out.println("===================================================================");
		
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		
			// Evaluating TriRank.
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, 
				aspectFilteringMode, 1);
		//checkUserAspects();
		
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		int maxIter = 10;
		
		Long start = System.currentTimeMillis();
		TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix,
				itemAspect, userAspect.transpose(), map_aspect_id);
		triRank.initModel(maxIter, showProgress, topK, alpha, beta, gamma, alpha0, beta0, gamma0);
		metrics = RunModelMultiThread(triRank, threadNum);
		
		double hr = metrics.getHitRatio(false);
		double ndcg = metrics.getNDCG(topK, false);
		System.out.printf("TriRank\t %.4f\t %.4f ", hr, ndcg);
		System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		printEvaluation(metrics, 10, 50);

		/*
		 * 		//SVDLIBCUtil.SparseMatrixToST(trainMatrix, String.format("SVDLIBC/data/%s.st", dataset_name));
		//readRatingsAndPosFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, 1);
		double[] rs = {0.01, 0.1, 0.5, 1, 5, 10, 50, 100, 200, 500, 1000};
		for(double regularizer : rs) {
			SVD svd = new SVD(trainMatrix, validMatrix, testMatrix, minValue, maxValue);
			svd.buildModel(20, 0.005, regularizer, 200, false);
			metrics = svd.evaluate(topK, testMatrix);
			System.out.printf("SVD(%.2f)\t %.4f\t %.4f \n", regularizer, metrics.getHitRatio(), metrics.getNDCG(topK));
		}*/
	}
	
	public static void OutputRatingFile(SparseMatrix M, String outputFile) 
			throws FileNotFoundException {
		PrintWriter writer = new PrintWriter (new FileOutputStream(outputFile));
        
        for (int i = 0; i < M.length()[0]; i++) {
        	SparseVector row = M.getRowRef(i);
        	if (row.itemCount() == 0)	continue;
        	for (int j : row.indexList()) {
        		writer.printf("%d\t%d\t%.1f\n", i, j, M.getValue(i, j));
        	}
        }
        writer.close();
        System.out.println("Generated file: " + outputFile);
	}
}
