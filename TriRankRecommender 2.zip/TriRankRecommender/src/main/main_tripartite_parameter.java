package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;


public class main_tripartite_parameter extends main {
	
	/**
	 * Tuning parameters of tripartiteRank.
	 * Fixed alpha, beta, gamma, and grid search on a0, b0, g0.
	 * @param argv
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static void main(String argv[]) throws IOException, InterruptedException {
		String dataset_name = "yelp_reviews_220K_i10_u10";
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";		

		//String dataset_name = "Electronics_i10_u10";
		//String lexiconFile = "datasets/lexicon/Electronics.lexicon";
		//alpha = 11; beta = 6; gamma = 0.2; alpha0 = 0.12; beta0 = 2; gamma0 = 1; // 18.44, 12.36
		//alpha = 11; beta = 6.2; gamma = 0.05; alpha0 = 0.1; beta0 = 1.95; gamma0 = 0.8; // 18.40, 12.39

		int threadNum = 2;
		String aspectFilteringMode = "tfidf";
		
		double alpha, beta, gamma, alpha0, beta0, gamma0;
		alpha = 6; beta = 3; gamma = 0.05; alpha0=5; beta0=100; gamma0 = 80;
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			if (dataset_name.contains("yelp"))	lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
			if (dataset_name.contains("Electronics"))	lexiconFile = "datasets/lexicon/Electronics.lexicon";
			alpha = Double.parseDouble(argv[1]);
			//beta = Double.parseDouble(argv[2]);
			//gamma = Double.parseDouble(argv[3]);
			threadNum = Integer.parseInt(argv[4]);
		}
		System.out.printf("Tuning parameters for dataset: %s \n", dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		// Read votes file with split:
		// DatasetUtil.SplitsVotesFileByTimeAllButK("datasets/", dataset_name, 3);
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, 
				aspectFilteringMode, 1);
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
				
		System.out.println("===================================================================");
		
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		EvaluationMetrics metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		
		// System.out.printf("alpha = %.2f, beta = %.2f, gamma = %.2f \n", alpha, beta, gamma);
		double bestHit = 0;
		//double[] as = {5, 5.2, 5.4, 5.6, 5.8, 6, 6.2, 6.4, 6.6, 6.8, 7, 7.5, 8, 9, 10, 15, 20, 30, 50, 100};
		double[] bs = {2, 2.2, 2.4, 2.6, 2.8, 3, 3.2, 3.4, 3.6, 3.8, 4, 5, 6, 10, 15, 20, 30, 40, 50, 100}; 
		//double[] gs = {0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.2, 0.4, 0.5, 1, 2, 4};
		//double[] a0s = {0.01, 0.03, 0.05, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.15, 0.17, 0.2, 0.3, 0.4, 0.5, 1, 2, 5};
		//double[] b0s = {1.5, 1.6, 1.8, 1.85, 1.9, 1.95, 2, 2.05, 2.1, 2.15, 2.2, 2.4, 2.6, 2.8, 3};
		//double[] g0s = {0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 2,3,4,5};
		for (double b : bs) {
			metrics = runTriRank(threadNum, alpha, beta=b, gamma, alpha0, beta0, gamma0);
			double hitRatio = metrics.getHitRatio(false);
			if (hitRatio > bestHit) 	bestHit = hitRatio;
		}
		System.out.printf("Best hitRatio is %.4f \n", bestHit);
	}
	
	public static EvaluationMetrics runTriRank(int threadNum, double alpha, double beta, double gamma, double alpha0, double beta0, double gamma0) throws InterruptedException {
		int topK = 50;
		Long start = System.currentTimeMillis();
		TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix,
				itemAspect, userAspect.transpose(), map_aspect_id);
		triRank.initModel(10, false, topK, alpha, beta, gamma, alpha0, beta0, gamma0);
		
		// Run the model multi-thread.
		ModelThread[] threads = new ModelThread[threadNum];
		int userCount = map_user_id.size();
		for (int t = 0; t < threadNum; t ++) {
			int startUser = (userCount / threadNum) * t;
			int endUser = (t == threadNum-1) ? userCount : (userCount / threadNum) * (t+1);
			threads[t] = new ModelThread(triRank, startUser, endUser);
			threads[t].start();
		}
		for (int t = 0; t < threads.length; t++) { // wait until all threads are finished.
			  threads[t].join();
		}
		
		EvaluationMetrics metrics = triRank.evaluate(testMatrix);
		System.out.printf("%.4f\t %.4f ", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		return metrics;
	}
}
