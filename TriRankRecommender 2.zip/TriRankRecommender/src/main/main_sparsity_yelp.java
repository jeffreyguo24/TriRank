package main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemKNN;
import algorithms.ItemPopularity;
import algorithms.ItemRank;
import algorithms.PageRank;
import algorithms.PureSVD;
import algorithms.SVD;
import algorithms.TagRW;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

/**
 * Randomly sample from the .votes file to build sparse dataset.
 * @author xiangnanhe
 *
 */
public class main_sparsity_yelp extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		double alpha, beta, gamma, alpha0, beta0, gamma0; 
		alpha=6; beta=3; gamma=0.05; alpha0=5; beta0=100; gamma0=80;
		
		String dataset_name = "yelp_reviews_220K_i10_u10";
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";		
		double sampleRate = 1;
		
		boolean showProgress = false;
		int threadNum = 3;
		int topK = 50;
		
		// Parsing the arguments
		if (argv.length > 0) {
			alpha = Double.parseDouble(argv[0]);
			beta  = Double.parseDouble(argv[1]);
			gamma = Double.parseDouble(argv[2]);
			alpha0= Double.parseDouble(argv[3]);
			beta0 = Double.parseDouble(argv[4]);
			gamma0= Double.parseDouble(argv[5]);
			
			sampleRate = Double.parseDouble(argv[6]);
			threadNum = Integer.parseInt(argv[7]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		int iter = 1;
		while (true) {
			
		readRatingsFromSplits(trainFile, validFile, testFile);
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, "tfidf", 1);
		randomSample(sampleRate);
		SVDLIBCUtil.SparseMatrixToST(trainMatrix, String.format("datasets/sample/%s.%.2f.%d.st",dataset_name, sampleRate, iter ++));
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		System.out.println("===================================================================");
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		
		// ItemPop
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		EvaluationMetrics metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 

		// TriRank
		Long start = System.currentTimeMillis();
		TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect.transpose(), map_aspect_id);
		triRank.initModel(10, showProgress, topK, alpha, beta, gamma, alpha0, beta0, gamma0);
		metrics = RunModelMultiThread(triRank, threadNum);
		System.out.printf("TriRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		
		// BiRank
		start = System.currentTimeMillis();
		triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect.transpose(), map_aspect_id);
		triRank.initModel(10, showProgress, topK, alpha, 0, 0, alpha0, beta0, 0);
		metrics = RunModelMultiThread(triRank, threadNum);
		System.out.printf("BiRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		
		// ItemKNN
		start = System.currentTimeMillis();
		ItemKNN itemKNN = new ItemKNN(trainMatrix, validMatrix, testMatrix);
		itemKNN.initModel(showProgress, 0);
		metrics = RunModelMultiThread(itemKNN, threadNum);
		System.out.printf("ItemKNN\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		
		/*
		// PureSVD
		start = System.currentTimeMillis();
		PureSVD pureSVD = new PureSVD(trainMatrix, validMatrix, testMatrix);
		pureSVD.initModel(String.format("SVDLIBC/output/%s/%d/-Ut", dataset_name, 20), String.format("SVDLIBC/output/%s/%d/-Vt", dataset_name, 20));
		metrics = RunModelMultiThread(pureSVD, threadNum);
		System.out.printf("PureSVD\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(true), metrics.getNDCG(topK, true), Printer.printTime(System.currentTimeMillis() - start));
		*/
		
		// PageRank
		start = System.currentTimeMillis();
		PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect, 0, 0);
		pagerank.initModel(10, showProgress, 0.9);
		metrics = RunModelMultiThread(pagerank, threadNum);
		System.out.printf("PageRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		
		// TagRW
		start = System.currentTimeMillis();
		TagRW rw = new TagRW(trainMatrix, validMatrix, testMatrix, itemAspect, userAspect);
		rw.initModel(5, false, 0.95, 0.1, 0.2, 0.3, 0.8);
		metrics = RunTagRWMultiThread(rw, threadNum);
		System.out.printf("TagRW\t %.4f\t %.4f [%s]\n\n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		
		// ItemRank
		start = System.currentTimeMillis();
		ItemRank itemrank = new ItemRank(trainMatrix, validMatrix, testMatrix);
		itemrank.initModel(10, showProgress, 0.9);
		metrics = RunModelMultiThread(itemrank, threadNum);
		System.out.printf("ItemRank\t %.4f\t %.4f [%s] \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false), Printer.printTime(System.currentTimeMillis() - start));
		}
	}
	
	public static void OutputRatingFile(SparseMatrix M, String outputFile) 
			throws FileNotFoundException {
		PrintWriter writer = new PrintWriter (new FileOutputStream(outputFile));
        
        for (int i = 0; i < M.length()[0]; i++) {
        	SparseVector row = M.getRowRef(i);
        	if (row.itemCount() == 0)	continue;
        	for (int j : row.indexList()) {
        		writer.printf("%d\t%d\t%.1f\n", i, j, M.getValue(i, j));
        	}
        }
        writer.close();
        System.out.println("Generated file: " + outputFile);
	}
	
	public static void randomSample(double sampleRate) {
		if (sampleRate >= 1)	return;
		for (int u = 0; u < map_user_id.size(); u ++) {
			for (int i : trainMatrix.getRowRef(u).indexArrayList()) {
				if (Math.random() > sampleRate) {
					trainMatrix.setValue(u, i, 0);
				}
			}
		}
		System.out.printf("SampleRate = %.2f, #trains = %d, ", sampleRate, trainMatrix.itemCount());
	}
}
