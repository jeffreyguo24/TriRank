package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import utils.Printer;
import algorithms.ItemRank;
import algorithms.ItemKNN;

public class main_itemknn extends main{
	public static void main(String argv[]) throws IOException, InterruptedException {
		//String dataset_name = "yelp_reviews_220K_i10_u10";
		//String dataset_name = "Electronics_i10_u10";
		String dataset_name = "yelp_reviews_220K_u3_9";
		
		int threadNum = 3;
		
		Boolean showProgress = false;
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			showProgress = Boolean.parseBoolean(argv[1]);
			threadNum = Integer.parseInt(argv[2]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		// Read votes file with split:
		// DatasetUtil.SplitsVotesFileByTimeAllButK("datasets/", dataset_name, 3);
		
		readRatingsFromSplits(trainFile, validFile, testFile);

		System.out.println("===================================================================");
		
		// Run baseline algorithms
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;
		
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		
		ItemKNN itemKNN = new ItemKNN(trainMatrix, validMatrix, testMatrix);
		for (int K = 0; K <= 200; K += 10) {
			//PageRank pagerank = new PageRank(trainMatrix, validMatrix, testMatrix, minValue, maxValue);
			Long start = System.currentTimeMillis();
			
			itemKNN.initModel(showProgress, K);
			metrics = RunModelMultiThread(itemKNN, threadNum);
			System.out.printf("ItemKNN\t %.4f\t %.4f ", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
			
			System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		}
	}
}
