package main;

import java.io.IOException;
import java.util.HashMap;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import data_structure.SparseMatrix;
import utils.Printer;


public class main_adsorption extends main{
	
	public static void main(String argv[]) throws IOException {
		//String dataset_name = "yelp_reviews_220K_i40_u40";
		String dataset_name = "Electronics_i10_u10";
		int maxIter = 10;
		int topK = 50;
		
		Boolean showProgress = true;
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			maxIter = Integer.parseInt(argv[1]);
			showProgress = Boolean.parseBoolean(argv[2]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		// Read votes file with split:
		// DatasetUtil.SplitsVotesFileByTimeAllButK("datasets/", dataset_name, 3);
		readRatingsFromSplits(trainFile, validFile, testFile);
		/*System.out.println("Rating matrices are converted to implicit..");
		trainMatrix = trainMatrix.implicit();
		validMatrix = validMatrix.implicit();
		testMatrix = testMatrix.implicit(); */
		System.out.println("===================================================================");
		
		// Run baseline algorithms
		EvaluationMetrics metrics;
		
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		
		for (double weight_p = 1; weight_p >= 0; weight_p -= 0.1) {
			Adsorption ads = new Adsorption(trainMatrix, validMatrix, testMatrix);
			ads.buildModel(maxIter, showProgress, weight_p);
			metrics = ads.evaluate(testMatrix);
			System.out.printf("Ads\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false));
		}
	}
}
