package main;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

/**
 * Study the aspects filtering on TriRank.
 * @author HeXiangnan
 *
 */

public class main_tripartite_aspects extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		double alpha, beta, gamma, alpha0, beta0, gamma0;
		/*String dataset_name = "yelp_reviews_220K_i10_u10";
		String lexiconFile = "datasets/lexicon/yelp_220K.lexicon";		
		alpha=6; beta=3; gamma=0.05; alpha0=5.00; beta0=100; gamma0=80;  */
		double dampUnrated = 1;
		
		String dataset_name = "Electronics_i10_u10";
		String lexiconFile = "datasets/lexicon/Electronics.lexicon";
		alpha=11.00; beta=6; gamma=0.2; alpha0=0.12; beta0=2.00; gamma0=1.00; //18.44
		
		int maxIter = 10;
		int threadNum = 3;
		
		// Parsing the arguments
		if (argv.length > 0) {
			dataset_name = argv[0];
			if (dataset_name.contains("yelp")){
				lexiconFile = "datasets/lexicon/yelp_220K.lexicon";
				alpha=6; beta=3; gamma=0.05; alpha0=5.00; beta0=100; gamma0=80; // 18.58
			}
			if (dataset_name.contains("Electronics"))	{
				lexiconFile = "datasets/lexicon/Electronics.lexicon";
				alpha=11.00; beta=6; gamma=0.2; alpha0=0.12; beta0=2.00; gamma0=1.00;  //18.44
			}
			threadNum = Integer.parseInt(argv[1]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		
		System.out.println("===================================================================");
		
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		
		String aspectFilteringMode = "tfidf";
		double step_size = 0.1;
		
		for (double ratio = 1; ratio > 0; ratio -= step_size) {
			if (ratio < 0.2)	step_size = 0.01;
			
			readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, lexiconFile, 
					aspectFilteringMode, ratio);	
			itemAspect = itemAspect.tf();
			userAspect = userAspect.tf();
			
			Long start = System.currentTimeMillis();
			TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix,
					itemAspect, userAspect.transpose(), map_aspect_id);
			triRank.initModel(maxIter, false, topK, alpha, beta, gamma, alpha0, beta0, gamma0);
			metrics = RunModelMultiThread(triRank, threadNum);
			
			System.out.printf("TriRank(ratio=%.2f)\t %.4f\t %.4f ", ratio, 
					metrics.getHitRatio(false), metrics.getNDCG(topK, false));
			System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
		}
	}
	
	public static void OutputRatingFile(SparseMatrix M, String outputFile) 
			throws FileNotFoundException {
		PrintWriter writer = new PrintWriter (new FileOutputStream(outputFile));
        
        for (int i = 0; i < M.length()[0]; i++) {
        	SparseVector row = M.getRowRef(i);
        	if (row.itemCount() == 0)	continue;
        	for (int j : row.indexList()) {
        		writer.printf("%d\t%d\t%.1f\n", i, j, M.getValue(i, j));
        	}
        }
        writer.close();
        System.out.println("Generated file: " + outputFile);
	}
}
