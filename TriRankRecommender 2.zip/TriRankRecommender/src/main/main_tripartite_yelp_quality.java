package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

/**
 * Experiments on Yelp with 124 high-quality features, given by Yongfeng Zhang.
 * @author HeXiangnan
 *
 */
public class main_tripartite_yelp_quality extends main {
	
	public static void main(String argv[]) throws IOException, InterruptedException {
		double alpha, beta, gamma, alpha0, beta0, gamma0;
		String dataset_name = "yelp_reviews_220K_i10_u10";
		String featureFile = "datasets/lexicon/yelp_220K.124.quality.feature";		
		alpha=3.00; beta=1; gamma=0; alpha0=5.00; beta0=4.00; gamma0=1.00; 
		
		boolean showProgress = false;
		int threadNum = 3;
		
		// Parsing the arguments
		if (argv.length > 0) {
			alpha = Double.parseDouble(argv[0]);
			beta  = Double.parseDouble(argv[1]);
			gamma = Double.parseDouble(argv[2]);
			threadNum = Integer.parseInt(argv[3]);
		}
		System.out.println("Run for dataset: " + dataset_name);
		
		String trainFile = "datasets/train/" + dataset_name + ".votes";
		String validFile = "datasets/validation/" + dataset_name + ".votes";
		String testFile  = "datasets/test/" + dataset_name + ".votes";
		
		readRatingsFromSplits(trainFile, validFile, testFile);
		System.out.println("===================================================================");
		
		int topK = 50;
		System.out.printf("Evaluating for topK = %d \nmethod\t Hit\t NDCG\n", topK);
		EvaluationMetrics metrics;
		ItemPopularity popularity = new ItemPopularity(trainMatrix, validMatrix, testMatrix);
		popularity.buildModel();
		metrics = popularity.evaluate(testMatrix);
		System.out.printf("ItemPop\t %.4f\t %.4f \n", metrics.getHitRatio(false), metrics.getNDCG(topK, false)); 
		

		// Evaluating TriRank.
		readRatingsAndFeaturesFromSplits(trainFile, validFile, testFile, featureFile);
		itemAspect = itemAspect.tf();
		userAspect = userAspect.tf();
		
		int maxIter = 10;
		double[] w1s = {2, 4, 8, 10, 15};
		double[] w2s = {5, 8, 10, 12, 15, 20};
		double[] w3s = {0.1, 0.2, 0.3};
		double bestHIT = 0;
		for (double w3 : w3s) {	
		for (double w1 : w1s) {
		for (double w2 : w2s) {
			Long start = System.currentTimeMillis();
			TripartiteRank triRank = new TripartiteRank(trainMatrix, validMatrix, testMatrix,
					itemAspect, userAspect.transpose(), map_aspect_id);
			triRank.initModel(maxIter, showProgress, topK, alpha, beta, gamma, alpha0=w1, beta0=w2, gamma0=w3);
			metrics = RunModelMultiThread(triRank, threadNum);
			
			double hit = metrics.getHitRatio(false);
			System.out.printf("TriRank\t %.4f\t %.4f ", hit, metrics.getNDCG(topK, false));
			System.out.printf("[%s] \n", Printer.printTime(System.currentTimeMillis() - start));
			bestHIT = bestHIT < hit ? hit : bestHIT;
		}
		}
		System.out.printf("Best HitRatio~(gamma0=%.2f) so far is %.4f \n", w3, bestHIT);
		}
	}
	
	/**
	 * Read the ratings from trainFile/validFile/testFile (file format: .votes).
	 * Read aspects (features) from featureFile.
	 * 
	 * @param trainFile
	 * @param validationFile
	 * @param testFile
	 * @param featureFile
	 * @throws IOException 
	 */
	public static void readRatingsAndFeaturesFromSplits(String trainFile, String validFile, 
			String testFile, String featureFile) throws IOException {
		if (trainMatrix == null) {
			readRatingsFromSplits(trainFile, validFile, testFile);
		}
		// Construct aspect dictionary.
		System.out.print("Building aspect matrix. ");
		long startTime = System.currentTimeMillis();
		map_aspect_id = new HashMap<String, Integer>();
		HashSet<String> aspects =  DatasetUtil.loadFeaturesFromFeatureFile(featureFile);
		//aspects.remove("food");
		//aspects.remove("restaurant");
		for (String aspect : aspects) {
			if (!map_aspect_id.containsKey(aspect)) {
				map_aspect_id.put(aspect, map_aspect_id.size());
			}
		}
		System.out.printf("Feature Count\t %d \n", map_aspect_id.size());
		// Construct aspect matrices.
		int userCount = map_user_id.size(), itemCount = map_item_id.size(), 
				aspectCount = map_aspect_id.size();
		userAspect = new SparseMatrix(userCount, aspectCount);
		itemAspect = new SparseMatrix(itemCount, aspectCount);
		DatasetUtil.buildAspectsMatrix(trainFile, map_user_id, map_item_id, map_aspect_id, 
				itemAspect, userAspect);
		System.out.printf("[time: %s]\n", Printer.printTime(System.currentTimeMillis() - startTime));
		
		System.out.printf("ItemAspect Density\t %.4f%%, Avg A:I = %.2f \n", 
				(double) itemAspect.itemCount() / (double) itemCount / (double) aspectCount * 100, 
				(double) itemAspect.itemCount() / (double) itemCount);
		System.out.printf("UserAspect Density\t %.4f%%, Avg A:U = %.2f \n", 
				(double) userAspect.itemCount() / (double) userCount / (double) aspectCount * 100, 
				(double) userAspect.itemCount() / (double) userCount);
	}
}
