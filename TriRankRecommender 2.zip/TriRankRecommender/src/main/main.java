package main;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;

import algorithms.Adsorption;
import algorithms.ItemPopularity;
import algorithms.PageRank;
import algorithms.SVD;
import algorithms.TagRW;
import algorithms.TopKRecommender;
import algorithms.TripartiteRank;
import utils.DatasetUtil;
import utils.EvaluationMetrics;
import utils.SVDLIBCUtil;
import data_structure.SparseMatrix;
import data_structure.SparseVector;
import utils.Printer;
import utils.CommonUtils;

import java.util.Map;
import java.util.ArrayList;

/**
 * This is an abstract class for evaluating topK recommender systems (i.e. main functions.).
 * Define some variables to use, and member functions to load data.
 * 
 * @author HeXiangnan
 * @since 2014.12.16
 */

class ModelThread extends Thread {
	TopKRecommender model;
	int startUser;
	int endUser;
	public ModelThread(TopKRecommender model, int startUser, int endUser) {
		this.model = model;
		this.startUser = startUser;
		this.endUser = endUser;
	}
	
	public void run() {
		model.buildModel(startUser, endUser);
	}
}

class TagRWThread extends Thread {
	TagRW model;
	int startUser, endUser;
	int startItem, endItem;
	public TagRWThread(TagRW model, int startUser, int endUser, int startItem, int endItem) {
		this.model = model;
		this.startUser = startUser;
		this.endUser = endUser;
		this.startItem = startItem;
		this.endItem = endItem;
	}
	
	public void run() {
		model.buildModelUser(startUser, endUser);
		model.buildModelItem(startItem, endItem);
	}
}

public abstract class main {

	/** Rating matrix for train/validation/test items. Users * Items matrix*/ 
	public static SparseMatrix trainMatrix;
	public static SparseMatrix validMatrix;
	public static SparseMatrix testMatrix;
	
	/** Map from user/item/aspect name to its ID, provided with the dataset. */
	public static HashMap<String, Integer> map_item_id; 
	public static HashMap<String, Integer> map_user_id;
	public static HashMap<String, Integer> map_aspect_id;
	
	/** Aspect matrices for TipartiteRank. Each entry denotes #times the aspect has been mentioned 
	 * for the item or user. */
	public static SparseMatrix itemAspect;
	public static SparseMatrix userAspect;
	
	/**
	 * Read the ratings from trainFile/validFile/testFile (file format: .votes).
	 * 	Store train/validation/test ratings in ratingMatrix/validationMatrix/testMatrix, respectively.
	 * 	Store all the dictionary of users/items in map_id_item/map_id_user.
	 * @throws LangDetectException 
	 */	
	public static void readRatingsFromSplits(String trainFile, String validFile, String testFile) 
			throws IOException {
			// Step 1. Build the dictionary of items, users.
			map_item_id = new HashMap<String, Integer>();
			map_user_id = new HashMap<String, Integer>();
			
			System.out.print("Building dictionary of users and items ");
			long startTime = System.currentTimeMillis();
			DatasetUtil util = new DatasetUtil();
			util.buildItemsAndUsersDictionary(trainFile, map_item_id, map_user_id);
			util.buildItemsAndUsersDictionary(validFile, map_item_id, map_user_id);
			util.buildItemsAndUsersDictionary(testFile, map_item_id, map_user_id);
			long endTime = System.currentTimeMillis();
			System.out.printf("[time: %s]\n", Printer.printTime(endTime - startTime));
			
			// Step 2. Build rateMatrix, validationMatrix, testMatrix.
			int userCount = map_user_id.size(), itemCount = map_item_id.size();
			trainMatrix = new SparseMatrix(userCount, itemCount);
			validMatrix = new SparseMatrix(userCount, itemCount);
			testMatrix = new SparseMatrix(userCount, itemCount);
			
			System.out.print("Building rating matrix ");
			startTime = System.currentTimeMillis();
			util.buildRatingMatrix(trainFile, trainMatrix, map_item_id, map_user_id);
			util.buildRatingMatrix(validFile, validMatrix, map_item_id, map_user_id);
			util.buildRatingMatrix(testFile, testMatrix, map_item_id, map_user_id);
			endTime = System.currentTimeMillis();
			// util.cleanRatingMatrix(trainMatrix, testMatrix);
			System.out.printf("[time: %s]\n", Printer.printTime(endTime - startTime));
			
			// Print some basic statistics of the dataset.
			int allRatingCount = trainMatrix.itemCount() + validMatrix.itemCount() + 
					testMatrix.itemCount();
			System.out.println ("Data File\t" + trainFile + "(train, validation, test)");
			System.out.println ("User Count\t" + userCount);
			System.out.println ("Item Count\t" + itemCount);
			System.out.printf("Rating Count\t %d (all), %d (train), %d (validation), %d(test)\n", 
					allRatingCount, trainMatrix.itemCount(), validMatrix.itemCount(), 
					testMatrix.itemCount());
			System.out.println ("Rating Density\t" + String.format("%.4f", 
					((double) allRatingCount / (double) userCount / (double) itemCount * 100.0)) + "%");
		}
	
	/**
	 * Read the ratings from trainFile/validFile/testFile (file format: .votes).
	 * Read aspects (features) from lexiconFile.
	 * 
	 * @param trainFile
	 * @param validationFile
	 * @param testFile
	 * @param lexiconFile
	 * @param aspectRatio Percentage of top aspects to read.
	 * @throws IOException 
	 */
	public static void readRatingsAndFeaturesFromSplits(String trainFile, String validFile, 
			String testFile, String lexiconFile, String filteringMode, double aspectRatio) throws IOException {
		if (trainMatrix == null) {
			readRatingsFromSplits(trainFile, validFile, testFile);
		}
		// Construct aspect dictionary.
		System.out.print("Building aspect matrix. ");
		long startTime = System.currentTimeMillis();
		map_aspect_id = new HashMap<String, Integer>();
		HashSet<String> aspects =  new HashSet<String>(
				DatasetUtil.loadFeaturesFromLexiconFile(lexiconFile, 1).keySet());
		//aspects.remove("food");
		//aspects.remove("restaurant");
		for (String aspect : aspects) {
			if (!map_aspect_id.containsKey(aspect)) {
				map_aspect_id.put(aspect, map_aspect_id.size());
			}
		}
		// Construct aspect matrices.
		int userCount = map_user_id.size(), itemCount = map_item_id.size(), 
				aspectCount = map_aspect_id.size();
		userAspect = new SparseMatrix(userCount, aspectCount);
		itemAspect = new SparseMatrix(itemCount, aspectCount);
		DatasetUtil.buildAspectsMatrix(trainFile, map_user_id, map_item_id, map_aspect_id, 
				itemAspect, userAspect);
		System.out.printf("[time: %s]\n", Printer.printTime(System.currentTimeMillis() - startTime));
		
		filteringAspects(aspectRatio, filteringMode);
		
		System.out.printf("Selected Feature Count\t %d (%.2f%%)\n", map_aspect_id.size(), aspectRatio*100);
		System.out.printf("ItemAspect Density\t %.4f%%, Avg A:I = %.2f \n", 
				(double) itemAspect.itemCount() / (double) itemCount / (double) aspectCount * 100, 
				(double) itemAspect.itemCount() / (double) itemCount);
		System.out.printf("UserAspect Density\t %.4f%%, Avg A:U = %.2f \n", 
				(double) userAspect.itemCount() / (double) userCount / (double) aspectCount * 100, 
				(double) userAspect.itemCount() / (double) userCount);
	}
	
	/**
	 * Read the ratings from trainFile/validFile/testFile (file format: .votes).
	 * Read aspects (positive feature-opinion pair) from lexiconFile.
	 * 
	 * @param trainFile
	 * @param validationFile
	 * @param testFile
	 * @param lexiconFile
	 * @param aspectRatio Percentage of top aspects to read.
	 * @throws IOException 
	 */
	public static void readRatingsAndPosFeaturesFromSplits(String trainFile, String validFile, 
			String testFile, String lexiconFile, double aspectRatio) throws IOException {
		if (trainMatrix == null) {
			readRatingsFromSplits(trainFile, validFile, testFile);
		}
		// Construct aspect dictionary.
		System.out.print("Building aspect matrix. ");
		long startTime = System.currentTimeMillis();
		HashMap<String, HashSet<String>> map_feature_opinions = 
				DatasetUtil.loadPosFeaturesFromLexiconFile(lexiconFile, aspectRatio);
		map_aspect_id = new HashMap<String, Integer>();
		for (String feature : map_feature_opinions.keySet()) {
			for (String opinion : map_feature_opinions.get(feature)) {
				map_aspect_id.put(feature + "|" + opinion, map_aspect_id.size());
			}
		}
		// Construct aspect matrices.
		int userCount = map_user_id.size(), itemCount = map_item_id.size(), 
				aspectCount = map_aspect_id.size();
		userAspect = new SparseMatrix(userCount, aspectCount);
		itemAspect = new SparseMatrix(itemCount, aspectCount);
		// TODO: problem with constructing FO pairs.
		DatasetUtil.buildAspectsMatrix_FO(trainFile, map_user_id, map_item_id, map_aspect_id, 
				itemAspect, userAspect, map_feature_opinions);
		System.out.printf("[time: %s]\n", Printer.printTime(System.currentTimeMillis() - startTime));
		
		System.out.printf("Selected Aspect Count\t %d (%.2f%%)\n", map_aspect_id.size(), aspectRatio*100);
		System.out.printf("ItemAspect Density\t %.4f%% \n", 
				(double) itemAspect.itemCount() / (double) itemCount / (double) aspectCount * 100);
		System.out.printf("UserAspect Density\t %.4f%% \n", 
				(double) userAspect.itemCount() / (double) userCount / (double) aspectCount * 100);
	}
	
	/**
	 * Filtering aspects by selecting top aspects.
	 * Set map_aspect_id, itemAspect, userAspect after filtering.
	 */
	public static void filteringAspects(double selectRatio, String mode) {
		System.out.printf("Filtering aspects with %s, selectRatio = %.2f\n", mode, selectRatio);
		HashMap<Integer, String> map_id_aspect = DatasetUtil.revertIDMap(map_aspect_id);
		HashMap<Integer, Double> map_aspectId_score = getAspectScore(itemAspect, mode);
		int selectAspectCount = (int) (itemAspect.length()[1] * selectRatio);

		// Set the filtered map_aspect_id
		ArrayList<Integer> topAspects = 
				CommonUtils.TopKeysByValue(map_aspectId_score, selectAspectCount, null);
		HashMap<String, Integer> new_map_aspect_id = new HashMap<String, Integer>();
		// Map from old aspectId to new aspectId.
		HashMap<Integer, Integer> map_old_new = new HashMap<Integer, Integer>(); 
		for (int i = 0; i < topAspects.size(); i ++) {
			int oldId = topAspects.get(i);
			int newId = new_map_aspect_id.size();
			new_map_aspect_id.put(map_id_aspect.get(oldId), newId);
			map_old_new.put(oldId, newId);
		}
		map_aspect_id = new_map_aspect_id;
		
		// Set the filtered itemAspect and userAspect.
		SparseMatrix newItemAspect = new SparseMatrix(itemAspect.length()[0], map_aspect_id.size());
		SparseMatrix newUserAspect = new SparseMatrix(userAspect.length()[0], map_aspect_id.size());
		for (int a = 0; a < itemAspect.length()[1]; a ++) {
			if (map_old_new.containsKey(a)) {
				int newId = map_old_new.get(a);
				newItemAspect.setColVector(newId, itemAspect.getColRef(a));
				newUserAspect.setColVector(newId, userAspect.getColRef(a));
			}
		}
		itemAspect = newItemAspect;
		userAspect = newUserAspect;
	}
	
	/**
	 * Get aspect score from itemAspect, based on the mode.
	 * @param itemAspect
	 * @param mode
	 * @return
	 */
	protected static HashMap<Integer, Double> getAspectScore(SparseMatrix itemAspect, String mode) {
		HashMap<Integer, Double> map_aspect_score = new HashMap<Integer, Double>();
		int aspectCount = itemAspect.length()[1];
		 
		if (mode.equals("count")) { // raw count of aspect
			for (int a = 0; a < aspectCount; a++) { 
				double score = itemAspect.getColRef(a).sum();
				map_aspect_score.put(a, score);
			}
		} else if (mode.equals("df")) { // number of items have the aspect
			for (int a = 0; a < aspectCount; a++) {
				double score = itemAspect.getColRef(a).itemCount();
				map_aspect_score.put(a, score);
			}
		} else if (mode.equals("tf")) { // sum of tf score.
			SparseMatrix tfMatrix = itemAspect.tf();
			for (int a = 0; a < aspectCount; a++) {
				double score = tfMatrix.getColRef(a).sum();
				map_aspect_score.put(a, score);
			}
		} else if (mode.equals("tfidf")) {  // sum of tfidf score.
			SparseMatrix tfidfMatrix = itemAspect.tfidf();
			for (int a = 0; a < aspectCount; a++) {
				double score = tfidfMatrix.getColRef(a).sum();
				map_aspect_score.put(a, score);
			}
		}
		
		return map_aspect_score;
	}
	
	public static void checkUserAspects() {
		System.out.println("user\t #Items\t #Aspects.");
		HashMap<Integer, String> map_id_user = DatasetUtil.revertIDMap(map_user_id);
		
		for (int u = 0; u < map_user_id.size(); u ++) {
			if (testMatrix.getRowRef(u).itemCount() == 0)	continue;
			//System.out.println(u + "\t" + testMatrix.getRowRef(u).itemCount());
			int items = trainMatrix.getRowRef(u).itemCount();
			int aspects = userAspect.getRowRef(u).itemCount();
			String aspect = DatasetUtil.aspectVectorToString(userAspect.getRowRef(u), map_aspect_id);
			System.out.printf("%d\t %s\t %d\t %d\t %s \n", u, map_id_user.get(u), items, aspects, aspect);
		}
	}
	
	public static void checkItemAspects() {
		System.out.println("item\t #Users\t #Aspects.");
		
		HashMap<Integer, String> map_id_item = DatasetUtil.revertIDMap(map_item_id);
		
		for (int i = 0; i < map_item_id.size(); i ++) {
			int users = trainMatrix.getColRef(i).itemCount();
			int aspects = itemAspect.getRowRef(i).itemCount();
			String aspect = DatasetUtil.aspectVectorToString(itemAspect.getRowRef(i), map_aspect_id);
			System.out.printf("%d\t %s\t %d\t %d\t %s \n", i, map_id_item.get(i), users, aspects, aspect);
		}
	}
	
	/**
	 * Run the recommender model multi-thread.
	 * @param model Initialized recommender model.
	 * @param topK  
	 * @param threadNum Number of threads to run the model.
	 * @return
	 * @throws InterruptedException
	 */
	public static EvaluationMetrics RunModelMultiThread(TopKRecommender model, int threadNum) 
			throws InterruptedException {
		ModelThread[] threads = new ModelThread[threadNum];
		int userCount = map_user_id.size();
		for (int t = 0; t < threadNum; t ++) {
			int startUser = (userCount / threadNum) * t;
			int endUser = (t == threadNum-1) ? userCount : (userCount / threadNum) * (t+1);
			threads[t] = new ModelThread(model, startUser, endUser);
			threads[t].start();
		}
		for (int t = 0; t < threads.length; t++) { // wait until all threads are finished.
			  threads[t].join();
		}
		
		return model.evaluate(testMatrix);
	}
	
	/**
	 * Run TagRW multi-thread.
	 * @param model Initialized TagRW model.
	 * @param threadNum Number of threads to run the model.
	 * @return
	 * @throws InterruptedException
	 */
	public static EvaluationMetrics RunTagRWMultiThread(TagRW model, int threadNum) 
			throws InterruptedException {
		TagRWThread[] threads = new TagRWThread[threadNum];
		int userCount = map_user_id.size();
		int itemCount = map_item_id.size();
		for (int t = 0; t < threadNum; t ++) {
			int startUser = (userCount / threadNum) * t;
			int endUser = (t == threadNum-1) ? userCount : (userCount / threadNum) * (t+1);
			int startItem = (itemCount / threadNum) * t;
			int endItem = (t == threadNum-1) ? itemCount : (itemCount / threadNum) * (t+1);
			threads[t] = new TagRWThread(model, startUser, endUser, startItem, endItem);
			threads[t].start();
		}
		for (int t = 0; t < threads.length; t++) { // wait until all threads are finished.
			  threads[t].join();
		}
		model.post(); // post process the model. 
		return model.evaluate(testMatrix);
	}
	
	/**
	 * Print out the topK evaluation results. 
	 * @param metrics EvaluationMetric object of the method
	 * @param startK Start k to evaluate for topK recommendation. 
	 * @param endK End k to evaluate for topK recommendation. 
	 */
	public static void printEvaluation(EvaluationMetrics metrics, int startK, int endK) {
		System.out.printf("\tHit@k  (%d - %d)\t", startK, endK);
		for (int k = startK; k <= endK; k ++) 	System.out.printf("%.4f\t", metrics.getHitRatio(k, false));
		System.out.printf("\n\tNDCG@k (%d - %d)\t", startK, endK);
		for (int k = startK; k <= endK; k ++) 	System.out.printf("%.4f\t", metrics.getNDCG(k, false));
		System.out.println("");
	}
}
